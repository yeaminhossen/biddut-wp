<?php


// product single social share
function youlink_product_social_share(){

    
    $post_url = get_the_permalink();
    ?>    
    <div class="product__details-share">
        <span><?php echo esc_html__('Share:', 'ninico'); ?></span>
        <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a>
        <a href="http://pinterest.com/pin/create/button/?url=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-pinterest-p"></i></a>
        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
        <a href="https://twitter.com/share?url=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-twitter"></i></a>
    </div>

    <?php

}
function biddut_poertfolio_social_share(){

    
    $post_url = get_the_permalink();
    ?>    
        <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a>
        <a href="http://pinterest.com/pin/create/button/?url=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-pinterest-p"></i></a>
        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
        <a href="https://twitter.com/share?url=<?php echo esc_url($post_url);?>" target="_blank"><i class="fa-brands fa-twitter"></i></a>

    <?php

}


function biddut_woo_social_share(){

    $finbest_singleblog_social = get_theme_mod( 'biddut_social_share_switch', true );

    if(!empty($finbest_singleblog_social)) : ?>

    <span><?php echo esc_html__('Share:','biddut'); ?></span>

    <a href="https://www.linkedin.com/shareArticle?url=<?php the_permalink(); ?>" target="_blank">
      <i class="fa-brands fa-linkedin-in"></i>
    </a>
    <a href="https://twitter.com/intent/tweet?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>" target="_blank">
      <i class="fab fa-twitter"></i>
    </a>
    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank">
      <i class="fab fa-facebook-f"></i>
    </a>

<?php endif ; 

}


add_action( 'biddut_woo_social_share','biddut_woo_social_share' );


