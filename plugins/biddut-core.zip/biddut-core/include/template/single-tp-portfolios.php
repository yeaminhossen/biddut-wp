<?php
/**
 * The main template file
 *
 * @package  WordPress
 * @subpackage  tpcore
 */
get_header();

$rep_values = function_exists('tpmeta_field') ? tpmeta_field('seomy_port_repeater') : '';
$image = function_exists('tpmeta_image_field') ? tpmeta_image_field('seomy_pro_img') : NULL;

$port_breadcrumb_shape = get_theme_mod('port_breadcrumb_shape', false);
$port_related_post = get_theme_mod('port_related_post', false);
$port_related_post_title = get_theme_mod('port_related_post_title', __('Related Portfolio Posts', 'seomy'));


$post_cats = get_the_terms(get_the_ID(), 'portfolios-cat');

$prev_post = get_previous_post();
$next_post = get_next_post();

?>

<div class="tp-porfolio-details-area project-details-customize pt-110 pb-105">
   <div class="container">
      <div class="tp-portfolio-details">
         <?php the_content(); ?> 
      </div>
      <div class="col-xl-12">
         <div class="postbox__thumb m-img p-relative pt-95 pb-45">
            <div class="postbox__details-share-wrapper">
               <div class="row">
                  <div class="col-xl-5 col-lg-6 col-md-6 col-sm-6">
                     <div class="postbox__details-tag tagcloud">
                     <?php 
                           $html = '';
                           foreach($post_cats as $key => $cat) {

                              $html .= '<a href="'.get_category_link($cat->term_id).'">'.$cat->name.'</a>';

                           }
                           echo rtrim($html,''); 

                        ?>
                     </div>
                  </div>
                  <div class="col-xl-7 col-lg-6 col-md-6 col-sm-6">
                     <div class="postbox__details-share text-start text-sm-end">
                        <?php biddut_poertfolio_social_share(); ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>


      <?php if(!empty($prev_post) && !empty($next_post))  : ?>                     
      <div class="postbox__more-navigation postbox__more-navigation-2 grey-bg-7 d-none d-sm-block">
         <div class="row g-0">
            <div class="col-md-6 col-sm-6">
               <div class="postbox__more-left p-relative d-flex align-items-center">
                  <div class="postbox__more-icon">
                     <a href="<?php echo get_the_permalink( $prev_post ); ?>">
                        <i class="fa-sharp fa-regular fa-arrow-left"></i>
                     </a>
                  </div>
                  <div class="postbox__more-content">
                     <p>Previous</p>
                     <h4>
                     <a href="<?php echo get_the_permalink( $prev_post ); ?>"><?php echo get_the_title($prev_post); ?></a>
                     </h4>
                  </div>
               </div>
            </div>
            <div class="col-md-6 col-sm-6">
               <div class="postbox__more-right p-relative d-flex align-items-center justify-content-end">
                  <div class="postbox__more-content text-end">
                     <p>Next</p>
                     <h4>
                     <a href="<?php echo get_the_permalink( $next_post ); ?>"><?php echo get_the_title($next_post); ?></a>
                     </h4>
                  </div>
                  <div class="postbox__more-icon">
                     <a href="<?php echo get_the_permalink( $next_post ); ?>">
                        <i class="fa-sharp fa-regular fa-arrow-right"></i>                                                    
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <?php endif; ?>
      </div>
   </div>
</div>


<!-- related portfolio query  -->

<?php
   // Get the current post ID
   $current_post_id = get_the_ID();

   // Get the categories of the current post
   $categories = get_the_terms($current_post_id, 'portfolios-cat');
   
   // If the post has categories, get related posts based on the first category
   if ($categories) :
      // $category_id = $categories[0]->term_id;

      $related_cat = [];
      foreach ($categories as $category) {
         $related_cat[] = $category->slug;
      }

      // Define custom query parameters
      $args = array(
            'post_type' => 'tp-portfolios', // Adjust post type if needed
            'posts_per_page' => 3, // Number of related posts to display
            'post__not_in' => array($current_post_id), // Exclude the current post
            'orderby' => 'rand', // Order by random; you can adjust this based on your preference
            'tax_query' => array(
               array(
                  'taxonomy' => 'portfolios-cat',
                  'field' => 'slug',
                  'terms' => $related_cat,
               )
            )
      );

      $related_posts_query = new WP_Query($args);

?>


<?php if ($related_posts_query->have_posts()) : ?>
<div class="tp-project-area pb-90">
   <div class="container">
      <div class="row">
         <div class="col-xl-12">
            <div class="tp-project-section-box text-center mb-60">
               <h4 class="tp-section-title">Check related projects</h4>
            </div> 
         </div>
         <div class="row">
            <?php
                  while ($related_posts_query->have_posts()) :
                  $related_posts_query->the_post();
                  $post_cats = get_the_terms(get_the_ID(), 'portfolios-cat');        
               ?>
            <div class="col-lg-4 col-md-6">
                  <div class="tp-project-item p-relative mb-30">
                     <div class="tp-project-thumb">
                        <?php the_post_thumbnail(); ?>
                     </div>
                     <div class="tp-project-content">
                        <a href="<?php the_permalink(); ?>"><i class="flaticon-right-arrow"></i></a>
                        <?php 
                        $html = '';
                        foreach($post_cats as $key => $cat) {

                           $html .= '<span><a href="'.get_category_link($cat->term_id).'">'.$cat->name.'</a></span>,';

                           if ($key == 0){ 
                              break;
                           } 

                        }
                        echo rtrim($html,','); 

                        ?>
                        <h4 class="tp-project-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                     </div>
                  </div>
            </div>
            <?php endwhile;  wp_reset_postdata(); ?>
            <?php endif; ?> 
         </div>
      </div>
   </div>
</div>
<?php endif; ?>


<?php get_footer();  ?>