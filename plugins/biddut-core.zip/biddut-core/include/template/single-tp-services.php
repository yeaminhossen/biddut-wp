<?php
/**
 * The main template file
 *
 * @package  WordPress
 * @subpackage  tpcore
 */
get_header();

$post_column = is_active_sidebar( 'services-sidebar' ) ? '8' : '10';
$post_column_center = is_active_sidebar( 'services-sidebar' ) ? '' : 'justify-content-center';

?>


      <div class="tp-service-details-area pt-120 pb-120">
         <div class="container">
            <div class="row justify-content-center">

               <?php if(is_active_sidebar( 'services-sidebar' )) : ?>
               <div class="col-xl-4 col-lg-4">
                  <div class="tp-service-details-left-box">
                     <?php dynamic_sidebar( 'services-sidebar' ); ?>
                  </div>
               </div>
               <?php endif; ?>

               <div class="col-xl-8 col-lg-8">
                  <div class="tp-service-details-right-wrap">
                     <?php the_content(); ?>
                  </div>
               </div>
            </div>
         </div>
      </div>

<?php get_footer();  ?>
