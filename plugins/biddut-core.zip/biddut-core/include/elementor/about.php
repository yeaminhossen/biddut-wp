<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use TPCore\Elementor\Controls\Group_Control_TPBGGradient;
use TPCore\Elementor\Controls\Group_Control_TPGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_About extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-about';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'About', 'tp-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tp-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  


	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tp-core'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tp-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tp-core'),
                    'layout-2' => esc_html__('Layout 2', 'tp-core'),
                    'layout-3' => esc_html__('Layout 3', 'tp-core'),
                    'layout-4' => esc_html__('Layout 4', 'tp-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->add_control(
            'tp_black_switch',
            [
                'label'        => esc_html__( 'Black On/Off', 'tpcore' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'tpcore' ),
                'label_off'    => esc_html__( 'Hide', 'tpcore' ),
                'return_value' => 'yes',
                'default'      => '0',
                'condition' => [
                    'tp_design_style' => 'layout-1'
                ]
            ]
        );        

        $this->end_controls_section();

        $this->tp_section_title_render_controls('about', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', ['layout-1', 'layout-2','layout-3']);


        $this->start_controls_section(
            'experience_section',
            [
                'label' => esc_html__( 'Experience Info', 'textdomain' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'tp_design_style' => ['layout-1', 'layout-2']
                ]
            ]
        );

        $this->add_control(
            'exp_image',
            [
                'label' => esc_html__( 'Choose Image', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'exp_number',
            [
                'label' => esc_html__( 'Number', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( '50', 'textdomain' ),
                'placeholder' => esc_html__( 'Type your text here', 'textdomain' ),
                'label_block' => true,
            ]
        ); 
        $this->add_control(
            'exp_content',
            [
                'label' => esc_html__( 'Content', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__( 'Content Here', 'textdomain' ),
                'placeholder' => esc_html__( 'Type your content here', 'textdomain' ),
            ]
        );

        $this->end_controls_section();


        // Features Sections
        $this->start_controls_section(
        'about_features_list_sec',
            [
                'label' => esc_html__( 'Features Box List', 'tpcore' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'tp_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6', 'layout-8', 'layout-9']
                ]
            ]
        );

        $this->add_control(
            'tp_light_switcher',
            [
                'label' => esc_html__( 'Light Version', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'tpcore' ),
                'label_off' => esc_html__( 'No', 'tpcore' ),
                'return_value' => 'yes',
                'default' => '0',
                'separator' => 'before',
                'condition' => [
                    'tp_design_style' => 'layout-2'
                ]
            ]
        );
        
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'tpcore' ),
                    'style_2' => __( 'Style 2', 'tpcore' ),
                    'style_3' => __( 'Style 3', 'tpcore' ),
                    'style_4' => __( 'Style 4', 'tpcore' ),
                    'style_5' => __( 'Style 5', 'tpcore' ),
                    'style_6' => __( 'Style 6', 'tpcore' ),
                    'style_7' => __( 'Style 7', 'tpcore' ),
                    'style_8' => __( 'Style 8', 'tpcore' ),
                    'style_9' => __( 'Style 9', 'tpcore' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'tp_box_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'tpcore'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'tpcore'),
                    'icon' => esc_html__('Icon', 'tpcore'),
                    'svg' => esc_html__('SVG', 'tpcore'),
                ],
            ]
        );
        $repeater->add_control(
            'tp_box_icon_svg',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'tpcore'),
                'condition' => [
                    'tp_box_icon_type' => 'svg',
                ]
            ]
        );

        $repeater->add_control(
            'tp_box_icon_image',
            [
                'label' => esc_html__('Upload Icon Image', 'tpcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_box_icon_type' => 'image',
                ]
            ]
        );

        if (tp_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'tp_box_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'tp_box_icon_type' => 'icon',
                    ]
                ]
            );
        } else {
            $repeater->add_control(
                'tp_box_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'tp_box_icon_type' => 'icon',
                    ]
                ]
            );
        }
        
        $repeater->add_control(
        'about_features_title',
            [
            'label'   => esc_html__( 'About List Title', 'tpcore' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => esc_html__( 'See the action in live', 'tpcore' ),
            'label_block' => true,
            'condition' => [
                'repeater_condition' => ['style_1', 'style_2', 'style_3', 'style_4', 'style_6', 'style_8', 'style_9']
            ]
            ]
        );
        
        $repeater->add_control(
        'about_features_des',
            [
            'label'   => esc_html__( 'Description', 'tpcore' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => esc_html__( 'Understand how your keyword/group is ranking specific cases.', 'tpcore' ),
            'label_block' => true,
            'condition' => [
                'repeater_condition' => ['style_2', 'style_4', 'style_5', 'style_6', 'style_8', 'style_9']
            ]
            ]
        );

        $repeater->add_control(
            'tp_about_link_switcher',
            [
                'label' => esc_html__( 'Add About link', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'tpcore' ),
                'label_off' => esc_html__( 'No', 'tpcore' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
                'condition' => [
                    'repeater_condition' => ['style_2', 'style_8']
                ]
            ]
        );
        
        $repeater->add_control(
        'about_features_btn_text',
            [
                'label'   => esc_html__( 'Button Text', 'tpcore' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Read More', 'tpcore' ),
                'label_block' => true,
                'condition' => [
                    'tp_about_link_switcher' => 'yes',
                    'repeater_condition' => ['style_2', 'style_8']
                ]
            ]
        );

        $repeater->add_control(
            'tp_about_link_type',
            [
                'label' => esc_html__( 'About Link Type', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'tp_about_link_switcher' => 'yes',
                    'repeater_condition' => ['style_2', 'style_8']
                ]
            ]
        );

        $repeater->add_control(
            'tp_about_link',
            [
                'label' => esc_html__( 'About Link link', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'https://your-link.com', 'tpcore' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'tp_about_link_type' => '1',
                    'tp_about_link_switcher' => 'yes',
                    'repeater_condition' => ['style_2', 'style_8']
                ]
            ]
        );
        $repeater->add_control(
            'tp_about_page_link',
            [
                'label' => esc_html__( 'Select About Link Page', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => tp_get_all_pages(),
                'condition' => [
                    'tp_about_link_type' => '2',
                    'tp_about_link_switcher' => 'yes',
                    'repeater_condition' => ['style_2', 'style_8']
                ]
            ]
        );
        
        $this->add_control(
            'about_features_list',
            [
            'label'       => esc_html__( 'About List', 'tpcore' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => [
                [
                'about_features_title'   => esc_html__( 'See the action in live', 'tpcore' ),
                ],
                [
                'about_features_title'   => esc_html__( 'Intuitive dashboard', 'tpcore' ),
                ],
            ],
            'title_field' => '{{{ about_features_title }}}',
            ]
        );
        
        $this->end_controls_section();


        // Features list Sections
        $this->start_controls_section(
        'about_features_list_simple',
            [
                'label' => esc_html__( 'Features List', 'tpcore' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'tp_design_style' => ['layout-1', 'layout-2','layout-4', 'layout-5', 'layout-6', 'layout-8', 'layout-9']
                ]
            ]
        );

        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
        'about_features_title_simple',
            [
            'label'   => esc_html__( 'List Title', 'tpcore' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => esc_html__( 'See the action in live', 'tpcore' ),
            'label_block' => true,
            ]
        );
        
        $this->add_control(
            'about_features_list_new',
            [
            'label'       => esc_html__( 'About List', 'tpcore' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'fields'      => $repeater->get_controls(),
            'default'     => [
                [
                'about_features_title_simple'   => esc_html__( 'See the action in live', 'tpcore' ),
                ],
                [
                'about_features_title_simple'   => esc_html__( 'Intuitive dashboard', 'tpcore' ),
                ],
            ],
            'title_field' => '{{{ about_features_title_simple }}}',
            ]
        );
        
        $this->end_controls_section();

        // Button    
        $this->tp_button_render('about', 'Button', ['layout-1', 'layout-2', 'layout-3']); 

        $this->start_controls_section(
            'quote_section',
            [
                'label' => esc_html__( 'Quote Text', 'textdomain' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'tp_design_style' => ['layout-2','layout-3']
                ]
            ]
        );

        $this->add_control(
            'quote_text',
            [
                'label' => esc_html__( 'Content', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__( 'Content Here', 'textdomain' ),
                'placeholder' => esc_html__( 'Type your content here', 'textdomain' ),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'sig_section',
            [
                'label' => esc_html__( 'Signature Image', 'textdomain' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'tp_design_style' => ['layout-1','layout-3']
                ]
            ]
        );

        $this->add_control(
            'sig_image',
            [
                'label' => esc_html__( 'Choose Image', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->end_controls_section();

        // _tp_image
		$this->start_controls_section(
            '_tp_image',
            [
                'label' => esc_html__('Thumbnail', 'tp-core'),
            ]
        );

        $this->add_control(
            'tp_image',
            [
                'label' => esc_html__( 'Choose Image', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'tp_image2',
            [
                'label' => esc_html__( 'Choose Image 2', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_design_style' => ['layout-1','layout-2', 'layout-3', 'layout-6', 'layout-7', 'layout-8']
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'tp_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();

        // shape
        $this->start_controls_section(
        'tp_shape',
            [
                'label' => esc_html__( 'Shape Section', 'tpcore' ),
                'condition' => [
                    'tp_design_style' => ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-6', 'layout-7', 'layout-8', 'layout-9']
                ]
            ]
        );

        $this->add_control(
        'tp_shape_switch',
        [
            'label'        => esc_html__( 'Shape On/Off', 'tpcore' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'tpcore' ),
            'label_off'    => esc_html__( 'Hide', 'tpcore' ),
            'return_value' => 'yes',
            'default'      => '0',
        ]
        );

        $this->add_control(
            'tp_shape_image_1',
            [
                'label' => esc_html__( 'Choose Shape Image 1', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_shape_switch' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'tp_shape_image_2',
            [
                'label' => esc_html__( 'Choose Shape Image 2', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_shape_switch' => 'yes',
                    'tp_design_style!' => 'layout-8', 
                    'tp_design_style' => ['layout-1','layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6', 'layout-7', 'layout-9']
                ]
            ]
        );

        $this->add_control(
            'tp_shape_image_3',
            [
                'label' => esc_html__( 'Choose Shape Image 3', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_shape_switch' => 'yes',
                    'tp_design_style!' => ['layout-2'], 
                    'tp_design_style' => ['layout-1', 'layout-4', 'layout-5', 'layout-6', 'layout-9']
                ]
            ]
        );
        
        $this->end_controls_section();

	}

    // style_tab_content
    protected function style_tab_content(){
        $this->tp_section_style_controls('about_section', 'Section - Style', '.tp-el-section');
        $this->tp_basic_style_controls('section_subtitle', 'Section - Subtitle', '.tp-el-subtitle', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6', 'layout-7', 'layout-8']);
        $this->tp_basic_style_controls('section_title', 'Section - Title', '.tp-el-title', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6', 'layout-7', 'layout-8']);
        $this->tp_basic_style_controls('section_desc', 'Section - Description', '.tp-el-content', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6', 'layout-7', 'layout-8']);
        $this->tp_link_controls_style('section_btn', 'Section - Button', '.tp-el-btn', ['layout-3', 'layout-6', 'layout-7']);
        $this->tp_link_controls_style('section_play_btn', 'Section - Play Button', '.tp-el-play', 'layout-5');
        # repeater 
        $this->tp_icon_style('rep_icon_style', 'Repeater Icon/Image/SVG', '.tp-el-rep-icon', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6', 'layout-8', 'layout-9']);
        $this->tp_basic_style_controls('rep_title_style', 'Repeater Title', '.tp-el-rep-title', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-6', 'layout-8', 'layout-9']);
        $this->tp_basic_style_controls('rep_des_style', 'Repeater Description', '.tp-el-rep-des', ['layout-2', 'layout-4', 'layout-5', 'layout-6', 'layout-8', 'layout-9']);
        $this->tp_link_controls_style('rep_btn_style', 'Repeater Button', '.tp-el-rep-btn', ['layout-1', 'layout-2', 'layout-8']);
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ) : 
    
    // thumbnail
    if ( !empty($settings['tp_image']['url']) ) {
        $tp_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
        $tp_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
    }

    // thumbnail 2
    if ( !empty($settings['tp_image2']['url']) ) {
        $tp_image2 = !empty($settings['tp_image2']['id']) ? wp_get_attachment_image_url( $settings['tp_image2']['id'], $settings['tp_image_size_size']) : $settings['tp_image2']['url'];
        $tp_image_alt2 = get_post_meta($settings["tp_image2"]["id"], "_wp_attachment_image_alt", true);
    }

    // shape image
    if ( !empty($settings['tp_shape_image_1']['url']) ) {
        $tp_shape_image = !empty($settings['tp_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['tp_shape_image_1']['id'], 'full') : $settings['tp_shape_image_1']['url'];
        $tp_shape_image_alt = get_post_meta($settings["tp_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
    }

    if ( !empty($settings['tp_shape_image_2']['url']) ) {
        $tp_shape_image2 = !empty($settings['tp_shape_image_2']['id']) ? wp_get_attachment_image_url( $settings['tp_shape_image_2']['id'], 'full') : $settings['tp_shape_image_2']['url'];
        $tp_shape_image_alt2 = get_post_meta($settings["tp_shape_image_2"]["id"], "_wp_attachment_image_alt", true);
    }

    // exp_image
    if ( !empty($settings['exp_image']['url']) ) {
        $exp_image = !empty($settings['exp_image']['id']) ? wp_get_attachment_image_url( $settings['exp_image']['id'], 'full') : $settings['exp_image']['url'];
        $exp_image_alt = get_post_meta($settings["exp_image"]["id"], "_wp_attachment_image_alt", true);
    }    


    $this->add_render_attribute('title_args', 'class', 'tp-section-title tp-el-title');


    // Link
    if ('2' == $settings['tp_about_btn_link_type']) {
        $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_about_btn_page_link']));
        $this->add_render_attribute('tp-button-arg', 'target', '_self');
        $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn tp-el-btn');
    } else {
        if ( ! empty( $settings['tp_about_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp-button-arg', $settings['tp_about_btn_link'] );
            $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn tp-el-btn');
        }
    } 
?>
  <div class="tp-about-2-area pt-120 pb-120 tp-el-section">
     <div class="container">
        <div class="row align-items-end">
           <div class="col-xl-6 col-lg-6 order-1 order-lg-0">
              <div class="tp-about-2-thumb-box p-relative">
                 <?php if(!empty($tp_shape_image)) : ?>
                 <div class="tp-about-2-shape-1 d-none d-xl-block">
                    <img src="<?php echo esc_url($tp_shape_image); ?>" alt="<?php echo esc_attr($tp_shape_image_alt); ?>">
                 </div>
                 <?php endif; ?>
                 <?php if(!empty($tp_image)) : ?>
                 <div class="tp-about-2-main-thumb z-index">
                    <img src="<?php echo esc_url($tp_image); ?>" alt="<?php echo esc_attr($tp_image_alt); ?>">
                 </div>
                 <?php endif; ?>
                 <?php if(!empty($tp_image2)) : ?>
                 <div class="tp-about-2-thumb-sm">
                    <img src="<?php echo esc_url($tp_image2); ?>" alt="<?php echo esc_attr($tp_image_alt2); ?>">
                 </div>
                 <?php endif; ?>
                 <?php if ( !empty($settings['exp_number']) ) : ?> 
                 <div class="tp-about-2-thumb-text d-none d-lg-block" style="background-image: url(<?php echo esc_url($exp_image); ?>);">
                    <h6><i class="purecounter" data-purecounter-duration="1" data-purecounter-end="<?php echo tp_kses( $settings['exp_number'] ); ?>">0</i>+</h6>
                    <span><?php echo tp_kses( $settings['exp_content'] ); ?></span>
                 </div>
                 <?php endif; ?>
              </div>
           </div>
           <div class="col-xl-6 col-lg-6 order-0 order-lg-1 wow tpfadeRight" data-wow-duration=".9s" data-wow-delay=".7s">
              <div class="tp-about-left-box tp-about-left-wrap">
                 <div class="tp-about-section-box mb-15">
                    <?php if ( !empty($settings['tp_about_sub_title']) ) : ?>
                    <span class="tp-section-subtitle"><?php echo tp_kses($settings['tp_about_sub_title']); ?></span>
                    <?php endif; ?>
                    <?php
                    if ( !empty($settings['tp_about_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['tp_about_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        tp_kses( $settings['tp_about_title' ] )
                        );
                    endif;
                    ?>
                 </div>
                 <div class="tp-about-text">
                    <?php if ( !empty($settings['tp_about_description']) ) : ?>
                    <p class="pb-15 tp-el-content"><?php echo tp_kses( $settings['tp_about_description'] ); ?></p>
                    <?php endif; ?>
                    <?php if ( !empty($settings['quote_text']) ) : ?>
                    <span><?php echo tp_kses( $settings['quote_text'] ); ?></span>
                    <?php endif; ?>
                    <div class="tp-about-icon-wrap p-relative d-flex justify-content-between mb-45">
                        <?php foreach($settings['about_features_list'] as $key => $item) : ?>
                       <div class="tp-about-icon-box d-flex align-items-center mb-20">
                          <div class="tp-about-icon">
                            <?php if($item['tp_box_icon_type'] == 'icon') : ?>
                            <?php if (!empty($item['tp_box_icon']) || !empty($item['tp_box_selected_icon']['value'])) : ?>
                            <span class="tp-el-rep-icon">
                                <?php tp_render_icon($item, 'tp_box_icon', 'tp_box_selected_icon'); ?>
                            </span>
                            <?php endif; ?>
                            <?php elseif( $item['tp_box_icon_type'] == 'image' ) : ?>
                            <?php if (!empty($item['tp_box_icon_image']['url'])): ?>
                            <span class="tp-el-rep-icon">
                                <img src="<?php echo $item['tp_box_icon_image']['url']; ?>"
                                    alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                            </span>
                            <?php endif; ?>
                            <?php else : ?>
                            <?php if (!empty($item['tp_box_icon_svg'])): ?>
                            <span class="tp-el-rep-icon">
                                <?php echo $item['tp_box_icon_svg']; ?>
                            </span>
                            <?php endif; ?>
                            <?php endif; ?>
                          </div>
                          <div class="tp-about-icon-text">
                            <?php if(!empty($item['about_features_title'])) : ?>
                            <h5><?php echo tp_kses($item['about_features_title']); ?></h5>
                            <?php endif; ?>
                          </div>
                       </div>
                       <?php endforeach; ?>

                       <div class="tp-about-list mb-20">
                          <ul>
                            <?php foreach($settings['about_features_list_new'] as $key => $item) : ?>
                                <?php if(!empty($item['about_features_title_simple'])) : ?>  
                                <li><i class="fa-light fa-badge-check"></i> <?php echo tp_kses($item['about_features_title_simple']); ?></li>
                                <?php endif; ?>
                             <?php endforeach; ?>
                          </ul>
                       </div>
                    </div>

                    <?php if ( !empty($settings['tp_about_btn_text']) ) : ?>
                        <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>><span><?php echo tp_kses($settings['tp_about_btn_text']); ?></span></a>
                    <?php endif; ?>
                 </div>
              </div>
           </div>
        </div>
     </div>
  </div>

<?php elseif ( $settings['tp_design_style']  == 'layout-3' ) : 
    
    // thumbnail
    if ( !empty($settings['tp_image']['url']) ) {
        $tp_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
        $tp_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
    }

    // thumbnail 2
    if ( !empty($settings['tp_image2']['url']) ) {
        $tp_image2 = !empty($settings['tp_image2']['id']) ? wp_get_attachment_image_url( $settings['tp_image2']['id'], $settings['tp_image_size_size']) : $settings['tp_image2']['url'];
        $tp_image_alt2 = get_post_meta($settings["tp_image2"]["id"], "_wp_attachment_image_alt", true);
    }

    // shape image
    if ( !empty($settings['tp_shape_image_1']['url']) ) {
        $tp_shape_image = !empty($settings['tp_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['tp_shape_image_1']['id'], 'full') : $settings['tp_shape_image_1']['url'];
        $tp_shape_image_alt = get_post_meta($settings["tp_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
    }

    if ( !empty($settings['tp_shape_image_2']['url']) ) {
        $tp_shape_image2 = !empty($settings['tp_shape_image_2']['id']) ? wp_get_attachment_image_url( $settings['tp_shape_image_2']['id'], 'full') : $settings['tp_shape_image_2']['url'];
        $tp_shape_image_alt2 = get_post_meta($settings["tp_shape_image_2"]["id"], "_wp_attachment_image_alt", true);
    }  


    // sig_image
    if ( !empty($settings['sig_image']['url']) ) {
        $sig_image = !empty($settings['sig_image']['id']) ? wp_get_attachment_image_url( $settings['sig_image']['id'], 'full') : $settings['sig_image']['url'];
        $sig_image_alt = get_post_meta($settings["sig_image"]["id"], "_wp_attachment_image_alt", true);
    }


    $this->add_render_attribute('title_args', 'class', 'tp-section-title tp-el-title');


    // Link
    if ('2' == $settings['tp_about_btn_link_type']) {
        $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_about_btn_page_link']));
        $this->add_render_attribute('tp-button-arg', 'target', '_self');
        $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn-black tp-el-btn');
    } else {
        if ( ! empty( $settings['tp_about_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp-button-arg', $settings['tp_about_btn_link'] );
            $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn-black tp-el-btn');
        }
    } 
?>
      <div class="tp-about-area p-relative pt-120 pb-120 tp-el-section">
         <?php if(!empty($tp_shape_image)) : ?>
         <div class="tp-about-shape-3">
            <img src="<?php echo esc_url($tp_shape_image); ?>" alt="<?php echo esc_attr($tp_shape_image_alt); ?>">
         </div>
         <?php endif; ?>
         <?php if(!empty($tp_shape_image2)) : ?>
         <div class="tp-about-shape-4 d-none d-xl-block">
            <img src="<?php echo esc_url($tp_shape_image2); ?>" alt="">
         </div>
         <?php endif; ?>
         <div class="container">
            <div class="row">
               <div class="col-xl-6 col-lg-6 wow tpfadeLeft" data-wow-duration=".9s" data-wow-delay=".5s">
                  <div class="tp-about-left-box">
                     <div class="tp-about-section-box mb-15">
                        <?php if ( !empty($settings['tp_about_sub_title']) ) : ?>
                        <span class="tp-section-subtitle"><?php echo tp_kses($settings['tp_about_sub_title']); ?></span>
                        <?php endif; ?>
                        <?php
                        if ( !empty($settings['tp_about_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['tp_about_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            tp_kses( $settings['tp_about_title' ] )
                            );
                        endif;
                        ?>

                     </div>
                     <div class="tp-about-text">
                        <?php if ( !empty($settings['tp_about_description']) ) : ?>
                        <p class="pb-15 tp-el-content"><?php echo tp_kses( $settings['tp_about_description'] ); ?></p>
                        <?php endif; ?>
                        <?php if ( !empty($settings['quote_text']) ) : ?>
                        <span><?php echo tp_kses( $settings['quote_text'] ); ?></span>
                        <?php endif; ?>
                        <div class="tp-about-icon-wrap p-relative d-flex justify-content-between mb-45">
                           <div class="tp-about-icon-shape d-none d-xl-block">
                              <img src="<?php echo get_template_directory_uri(); ?>/assets/img/about/shape-1-6.png" alt="">
                           </div>
                           <?php foreach($settings['about_features_list'] as $key => $item) : ?>
                           <div class="tp-about-icon-box d-flex align-items-center mb-20">
                              <div class="tp-about-icon">
                                    <?php if($item['tp_box_icon_type'] == 'icon') : ?>
                                    <?php if (!empty($item['tp_box_icon']) || !empty($item['tp_box_selected_icon']['value'])) : ?>
                                    <span class="tp-el-rep-icon">
                                        <?php tp_render_icon($item, 'tp_box_icon', 'tp_box_selected_icon'); ?>
                                    </span>
                                    <?php endif; ?>
                                    <?php elseif( $item['tp_box_icon_type'] == 'image' ) : ?>
                                    <?php if (!empty($item['tp_box_icon_image']['url'])): ?>
                                    <span class="tp-el-rep-icon">
                                        <img src="<?php echo $item['tp_box_icon_image']['url']; ?>"
                                            alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                    </span>
                                    <?php endif; ?>
                                    <?php else : ?>
                                    <?php if (!empty($item['tp_box_icon_svg'])): ?>
                                    <span class="tp-el-rep-icon">
                                        <?php echo $item['tp_box_icon_svg']; ?>
                                    </span>
                                    <?php endif; ?>
                                    <?php endif; ?>
                              </div>
                              <div class="tp-about-icon-text">
                                <?php if(!empty($item['about_features_title'])) : ?>
                                <h5><?php echo tp_kses($item['about_features_title']); ?></h5>
                                <?php endif; ?>
                              </div>
                           </div>
                           <?php endforeach; ?>

                        </div>
                        <div class="tp-about-button-box d-flex align-items-center">
                            <?php if ( !empty($settings['tp_about_btn_text']) ) : ?>
                                <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>><span><?php echo tp_kses($settings['tp_about_btn_text']); ?></span></a>
                            <?php endif; ?>
                            <?php if(!empty($sig_image)) : ?>   
                           <img src="<?php echo esc_url($sig_image); ?>" alt="<?php echo esc_attr($sig_image_alt); ?>">
                           <?php endif; ?>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6 wow tpfadeRight" data-wow-duration=".9s" data-wow-delay=".7s">
                  <div class="tp-about-right-box p-relative text-end">
                     <?php if(!empty($tp_image2)) : ?>
                     <div class="tp-about-main-thumb">
                        <img src="<?php echo esc_url($tp_image); ?>" alt="<?php echo esc_attr($tp_image_alt); ?>">
                     </div>
                     <?php endif; ?>
                     <?php if(!empty($tp_image2)) : ?>
                     <div class="tp-about-thumb-sm">
                        <img src="<?php echo esc_url($tp_image2); ?>" alt="<?php echo esc_attr($tp_image_alt2); ?>">
                     </div>
                     <?php endif; ?>
                     <div class="tp-about-shape-1 d-none d-lg-block">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/about/shape-1-2.png" alt="">
                     </div>
                     <div class="tp-about-shape-2  d-none d-lg-block">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/about/shape-1-3.png" alt="">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>



<?php else:

    // thumbnail
    if ( !empty($settings['tp_image']['url']) ) {
        $tp_image = !empty($settings['tp_image']['id']) ? wp_get_attachment_image_url( $settings['tp_image']['id'], $settings['tp_image_size_size']) : $settings['tp_image']['url'];
        $tp_image_alt = get_post_meta($settings["tp_image"]["id"], "_wp_attachment_image_alt", true);
    }

    // thumbnail 2
    if ( !empty($settings['tp_image2']['url']) ) {
        $tp_image2 = !empty($settings['tp_image2']['id']) ? wp_get_attachment_image_url( $settings['tp_image2']['id'], $settings['tp_image_size_size']) : $settings['tp_image2']['url'];
        $tp_image_alt2 = get_post_meta($settings["tp_image2"]["id"], "_wp_attachment_image_alt", true);
    }

    // shape image
    if ( !empty($settings['tp_shape_image_1']['url']) ) {
        $tp_shape_image = !empty($settings['tp_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['tp_shape_image_1']['id'], 'full') : $settings['tp_shape_image_1']['url'];
        $tp_shape_image_alt = get_post_meta($settings["tp_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
    }

    if ( !empty($settings['tp_shape_image_2']['url']) ) {
        $tp_shape_image2 = !empty($settings['tp_shape_image_2']['id']) ? wp_get_attachment_image_url( $settings['tp_shape_image_2']['id'], 'full') : $settings['tp_shape_image_2']['url'];
        $tp_shape_image_alt2 = get_post_meta($settings["tp_shape_image_2"]["id"], "_wp_attachment_image_alt", true);
    }

    // exp_image
    if ( !empty($settings['exp_image']['url']) ) {
        $exp_image = !empty($settings['exp_image']['id']) ? wp_get_attachment_image_url( $settings['exp_image']['id'], 'full') : $settings['exp_image']['url'];
        $exp_image_alt = get_post_meta($settings["exp_image"]["id"], "_wp_attachment_image_alt", true);
    }    

    // sig_image
    if ( !empty($settings['sig_image']['url']) ) {
        $sig_image = !empty($settings['sig_image']['id']) ? wp_get_attachment_image_url( $settings['sig_image']['id'], 'full') : $settings['sig_image']['url'];
        $sig_image_alt = get_post_meta($settings["sig_image"]["id"], "_wp_attachment_image_alt", true);
    }

    $this->add_render_attribute('title_args', 'class', 'tp-section-title tp-el-title');


    $black = $settings['tp_black_switch'] ? 'tp-black-mode black-bg' : ''; 

    $black_btn = $settings['tp_black_switch'] ? 'tp-btn-black red-bg tp-el-btn' : 'tp-btn-black tp-el-btn'; 

    // Link
    if ('2' == $settings['tp_about_btn_link_type']) {
        $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_about_btn_page_link']));
        $this->add_render_attribute('tp-button-arg', 'target', '_self');
        $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp-button-arg', 'class', $black_btn);
    } else {
        if ( ! empty( $settings['tp_about_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp-button-arg', $settings['tp_about_btn_link'] );
            $this->add_render_attribute('tp-button-arg', 'class', $black_btn);
        }
    }     

?>


<div class="tp-about-area p-relative pt-120 pb-120 tp-el-section <?php echo esc_attr($black); ?>">
 <?php if(!empty($tp_shape_image)) : ?>   
 <div class="tp-about-shape-5 d-none d-xl-block">
    <img src="<?php echo esc_url($tp_shape_image); ?>" alt="<?php echo esc_attr($tp_shape_image_alt); ?>">
 </div>
 <?php endif; ?>
 <div class="container">
    <div class="row">

       <div class="col-xl-6 col-lg-6 wow tpfadeLeft" data-wow-duration=".9s" data-wow-delay=".5s">
          <div class="tp-about-right-box text-end tp-about-right-wrap p-relative">

            <?php if ( !empty($settings['exp_number']) ) : ?> 
             <div class="tp-about-2-thumb-text text-start d-none d-lg-block" style="background-image: url(<?php echo esc_url($exp_image); ?>);">

                <?php if ( !empty($settings['exp_number']) ) : ?>
                <h6><i class="purecounter" data-purecounter-duration="1" data-purecounter-end="<?php echo tp_kses( $settings['exp_number'] ); ?>">0</i>+</h6>
                <?php endif; ?>    

                <?php if ( !empty($settings['exp_content']) ) : ?>
                <span><?php echo tp_kses( $settings['exp_content'] ); ?></span>
                <?php endif; ?>
             </div>
             <?php endif; ?>

             <?php if(!empty($tp_image)) : ?>
             <div class="tp-about-main-thumb">
                <img src="<?php echo esc_url($tp_image); ?>" alt="<?php echo esc_attr($tp_image_alt); ?>">
             </div>
             <?php endif; ?>

             <?php if(!empty($tp_image2)) : ?>
             <div class="tp-about-thumb-sm">
                <img src="<?php echo esc_url($tp_image2); ?>" alt="<?php echo esc_attr($tp_image_alt2); ?>">
             </div>
             <?php endif; ?>

             <?php if(!empty( $tp_shape_image2)) : ?>
             <div class="tp-about-shape-2  d-none d-lg-block">
                <img src="<?php echo esc_url( $tp_shape_image2); ?>" alt="<?php echo esc_attr($tp_shape_image_alt2); ?>">
             </div>
             <?php endif; ?>

             <?php if(!empty($tp_shape_image3)) : ?>
             <div class="tp-about-shape-6 d-none d-xl-block">
                <img src="<?php echo esc_url($tp_shape_image3); ?>" alt="<?php echo esc_attr($tp_shape_image_alt3); ?>">
             </div>
             <?php endif; ?>
          </div>
       </div>

       <div class="col-xl-6 col-lg-6 wow tpfadeRight" data-wow-duration=".9s" data-wow-delay=".7s">
          <div class="tp-about-left-box tp-about-ml">
             <div class="tp-about-section-box mb-15">
                <?php if ( !empty($settings['tp_about_sub_title']) ) : ?>
                <span class="tp-section-subtitle"><?php echo tp_kses($settings['tp_about_sub_title']); ?></span>
                <?php endif; ?>
                <?php
                if ( !empty($settings['tp_about_title' ]) ) :
                    printf( '<%1$s %2$s>%3$s</%1$s>',
                    tag_escape( $settings['tp_about_title_tag'] ),
                    $this->get_render_attribute_string( 'title_args' ),
                    tp_kses( $settings['tp_about_title' ] )
                    );
                endif;
                ?>
             </div>
             <div class="tp-about-text">
                <?php if ( !empty($settings['tp_about_description']) ) : ?>
                <p class="pb-15 tp-el-content"><?php echo tp_kses( $settings['tp_about_description'] ); ?></p>
                <?php endif; ?>
                <div class="tp-about-icon-wrap p-relative d-flex justify-content-between mb-40">
                   <div class="tp-about-icon-shape d-none d-xl-block">
                      <img src="<?php echo get_template_directory_uri(); ?>/assets/img/about/shape-1-6.png" alt="">
                   </div>
                    <?php foreach($settings['about_features_list'] as $key => $item) : ?>
                   <div class="tp-about-icon-box d-flex align-items-center mb-20">
                      <div class="tp-about-icon icon-color">
                        <?php if($item['tp_box_icon_type'] == 'icon') : ?>
                        <?php if (!empty($item['tp_box_icon']) || !empty($item['tp_box_selected_icon']['value'])) : ?>
                        <span class="tp-el-rep-icon">
                            <?php tp_render_icon($item, 'tp_box_icon', 'tp_box_selected_icon'); ?>
                        </span>
                        <?php endif; ?>
                        <?php elseif( $item['tp_box_icon_type'] == 'image' ) : ?>
                        <?php if (!empty($item['tp_box_icon_image']['url'])): ?>
                        <span class="tp-el-rep-icon">
                            <img src="<?php echo $item['tp_box_icon_image']['url']; ?>"
                                alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                        </span>
                        <?php endif; ?>
                        <?php else : ?>
                        <?php if (!empty($item['tp_box_icon_svg'])): ?>
                        <span class="tp-el-rep-icon">
                            <?php echo $item['tp_box_icon_svg']; ?>
                        </span>
                        <?php endif; ?>
                        <?php endif; ?>
                      </div>
                      <div class="tp-about-icon-text">
                        <?php if(!empty($item['about_features_title'])) : ?>
                        <h5 class="tp-el-rep-title"><?php echo tp_kses($item['about_features_title']); ?></h5>
                        <?php endif; ?>
                      </div>
                   </div>
                   <?php endforeach; ?>
                </div>

                <div class="tp-about-list mb-45">
                   <ul>
                      <?php foreach($settings['about_features_list_new'] as $key => $item) : ?>
                      <?php if(!empty($item['about_features_title_simple'])) : ?>  
                      <li><i class="fa-light fa-badge-check"></i> <?php echo tp_kses($item['about_features_title_simple']); ?></li>
                      <?php endif; ?>
                      <?php endforeach; ?>
                   </ul>
                </div>

                <div class="tp-about-button-box d-flex align-items-center">

                    <?php if ( !empty($settings['tp_about_btn_text']) ) : ?>
                        <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>><span><?php echo tp_kses($settings['tp_about_btn_text']); ?></span></a>
                    <?php endif; ?>

                    <?php if(!empty($sig_image)) : ?>   
                   <img src="<?php echo esc_url($sig_image); ?>" alt="<?php echo esc_attr($sig_image_alt); ?>">
                   <?php endif; ?>
                </div>
             </div>
          </div>
       </div>
    </div>
 </div>
</div>

<?php endif; 
        
	}
}

$widgets_manager->register( new TP_About() );