<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Blog_Post extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'blogpost';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Blog Post', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->add_control(
         'tp_black_switch',
         [
             'label'        => esc_html__( 'Black On/Off', 'tpcore' ),
             'type'         => \Elementor\Controls_Manager::SWITCHER,
             'label_on'     => esc_html__( 'Show', 'tpcore' ),
             'label_off'    => esc_html__( 'Hide', 'tpcore' ),
             'return_value' => 'yes',
             'default'      => '0',
             'condition' => [
                 'tp_design_style' => 'layout-1'
             ]
         ]
     );

        $this->end_controls_section();
        
        // Blog Query
        $this->tp_query_controls('blog', 'Blog','post');
        
        // section column
        $this->tp_columns('col', ['layout-1', 'layout-3', 'layout-4', 'layout-7']);

        // layout Panel
        $this->start_controls_section(
            'add_features_sec',
            [
                'label' => esc_html__('Additional Features', 'tpcore'),
            ]
        );
        $this->add_control(
        'tp_post_pagination',
        [
            'label'        => esc_html__( 'Pagination On/Off', 'tpcore' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'tpcore' ),
            'label_off'    => esc_html__( 'Hide', 'tpcore' ),
            'return_value' => 'yes',
            'default'      => '0',
        ]
        );

        $this->end_controls_section();

	}

    // style_tab_content
    protected function style_tab_content(){
		$this->tp_section_style_controls('blog_section', 'Section Style', '.tp-el-section');
        # repeater 
        $this->tp_link_controls_style('rep_cat_style', 'Blog Category', '.tp-el-rep-cat', ['layout-1', 'layout-2', 'layout-4', 'layout-5', 'layout-6', 'layout-7']);
        $this->tp_link_controls_style('rep_title_style', 'Blog Title', '.tp-el-rep-title', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6', 'layout-7']);
        $this->tp_basic_style_controls('rep_des_style', 'Blog Description', '.tp-el-rep-des', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6', 'layout-7']);
        $this->tp_link_controls_style('rep_btn_style', 'Blog Button', '.tp-el-rep-btn', ['layout-1', 'layout-2', 'layout-6']);
        $this->tp_icon_style('rep_avatar_style', 'Blog Avatar Icon/Image/SVG', '.tp-el-rep-avatar', 'layout-1');
        $this->tp_basic_style_controls('rep_ava_name_style', 'Blog Avatar Name', '.tp-el-rep-ava-name', ['layout-1', 'layout-4', 'layout-5', 'layout-6', 'layout-7']);
        $this->tp_basic_style_controls('rep_date_style', 'Blog Date', '.tp-el-rep-date', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6', 'layout-7']);
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        /**
         * Setup the post arguments.
        */
        $query_args = TP_Helper::get_query_args('post', 'category', $this->get_settings());

        // The Query
        $query = new \WP_Query($query_args);


        $filter_list = $settings['category'];

        ?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ) : ?>



  <div class="tp-blog-area p-relative pt-120 pb-130 tp-el-section">
     <div class="tp-blog-shape-1">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/blog/shape-1-3.png" alt="">
     </div>
     <div class="container">
        <div class="row">
            <?php if ($query->have_posts()) :
                $i = 0.0;
                while ($query->have_posts()) : 
                $query->the_post();
                global $post;
                $categories = get_the_category($post->ID);
                $author_id = get_the_author_meta('ID');
                $author_avatar_url = get_avatar_url($author_id);
                $i+=0.3;
            ?>
           <div class="col-xl-4 col-lg-4 col-md-6 mb-30  wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
              <div class="tp-blog-item">
                 <div class="tp-blog-thumb-wrap p-relative">
                    <div class="tp-blog-thumb-box p-relative">
                        <?php if(has_post_thumbnail()) : ?>
                       <div class="tp-blog-thumb-main z-index-3 fix">
                          <?php the_post_thumbnail(); ?>
                       </div>
                       <?php endif; ?>
                       <div class="tp-blog-thumb-icon">
                          <a href="<?php the_permalink(); ?>"><i class="fa-sharp fa-light fa-eye"></i></a>
                       </div>
                    </div>
                    <div class="tp-blog-thumb-shape-1">
                       <img src="<?php echo get_template_directory_uri(); ?> /assets/img/blog/shape-1-1.png" alt="">
                    </div>
                    <div class="tp-blog-thumb-shape-2">
                       <img src="<?php echo get_template_directory_uri(); ?> /assets/img/blog/shape-1-2.png" alt="">
                    </div>
                 </div>
                 <div class="tp-blog-content">
                    <div class="tp-blog-meta">
                       <span><i class="fa-light fa-circle-user"></i>By <?php echo ucwords(get_the_author()); ?></span>
                       <?php if(!empty($categories[0]->name)) : ?>
                       <span><i class="flaticon-price-tag"></i><?php echo esc_html($categories[0]->name); ?></span>
                       <?php endif; ?>
                    </div>
                    <h4 class="tp-blog-title"><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), $settings['tp_blog_title_word'], ''); ?></a></h4>
                    <?php if (!empty($settings['tp_post_content'])):
                        $tp_post_content_limit = (!empty($settings['tp_post_content_limit'])) ? $settings['tp_post_content_limit'] : '';
                            ?>
                    <p class="tp-el-rep-des"><?php print wp_trim_words(get_the_excerpt(get_the_ID()), $tp_post_content_limit, ''); ?></p>
                    <?php endif; ?>
                    <?php if(!empty($settings['tp_post_button'])) : ?>
                    <div class="tp-blog-link d-flex justify-content-between align-items-center">
                       <a href="<?php the_permalink(); ?>"><?php echo tp_kses($settings['tp_post_button']); ?></a>
                       <a href="<?php the_permalink(); ?>"><i class="flaticon-right-arrow"></i></a>
                    </div>
                    <?php endif; ?>
                 </div>
              </div>
           </div>
           <?php endwhile; wp_reset_query(); endif; ?>
        </div>
     </div>
  </div>

<?php if($settings['tp_post_pagination'] == 'yes' && '-1' != $settings['posts_per_page']) : ?>

<div class="basic-pagination mt-30">
    <?php
            $big = 999999999;

            if (get_query_var('paged')) {
                $paged = get_query_var('paged');
            } else if (get_query_var('page')) {
                $paged = get_query_var('page');
            } else {
                $paged = 1;
            }

            echo paginate_links( array(
                'base'       => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
                'format'     => '?paged=%#%',
                'current'    => $paged,
                'total'      => $query->max_num_pages,
                'type'       =>'list',
                'prev_text'  =>'<i>
                                          <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                             <path d="M11 6H1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                             <path d="M6 11L1 6L6 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                          </svg>
                                       </i> Prev Page',
                'next_text'  =>'Next page <i>
                                          <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                             <path d="M1 6H11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                             <path d="M6 11L11 6L6 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                          </svg>
                                       </i>',
                'show_all'   => false,
                'end_size'   => 1,
                'mid_size'   => 4,
            ) );
            ?>
</div>
<?php endif; ?>

<?php elseif ( $settings['tp_design_style']  == 'layout-3' ) : ?>
      <div class="tp-blog-area p-relative pt-120 pb-120 tp-el-section">
         <div class="container">
            <div class="row">
                <?php if ($query->have_posts()) :
                    $i = 0.0;
                    while ($query->have_posts()) : 
                    $query->the_post();
                    global $post;
                    $categories = get_the_category($post->ID);
                    $author_id = get_the_author_meta('ID');
                    $author_avatar_url = get_avatar_url($author_id);
                    $i+=0.3;
                ?>
               <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
                  <div class="tp-blog-item">
                     <div class="tp-blog-thumb-wrap p-relative">

                        <div class="tp-blog-thumb-box p-relative">
                           <div class="tp-blog-thumb-main z-index-3 fix">
                              <?php the_post_thumbnail(); ?>
                           </div>
                           <div class="tp-blog-thumb-icon">
                              <a href="<?php the_permalink(); ?>"><i
                                    class="fa-sharp fa-light fa-eye"></i></a>
                           </div>
                        </div>

                        <div class="tp-blog-thumb-shape-1">
                           <img src="<?php echo get_template_directory_uri(); ?>/assets/img/blog/shape-1-1.png" alt="">
                        </div>
                        <div class="tp-blog-thumb-shape-2">
                           <img src="<?php echo get_template_directory_uri(); ?>/assets/img/blog/shape-1-2.png" alt="">
                        </div>
                     </div>
                     <div class="tp-blog-content">
                        <div class="tp-blog-meta">
                           <span><i class="fa-light fa-circle-user"></i>By <?php echo ucwords(get_the_author()); ?></span>
                           <?php if(!empty($categories[0]->name)) : ?>
                           <span><i class="flaticon-price-tag"></i><?php echo esc_html($categories[0]->name); ?></span>
                           <?php endif; ?>
                        </div>

                          <h4 class="tp-blog-title"><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), $settings['tp_blog_title_word'], ''); ?></a></h4>

                        <?php if (!empty($settings['tp_post_content'])):
                            $tp_post_content_limit = (!empty($settings['tp_post_content_limit'])) ? $settings['tp_post_content_limit'] : '';
                                ?>
                        <p class="tp-el-rep-des"><?php print wp_trim_words(get_the_excerpt(get_the_ID()), $tp_post_content_limit, ''); ?></p>
                        <?php endif; ?> 
                        <?php if(!empty($settings['tp_post_button'])) : ?>
                        <div class="tp-blog-link d-flex justify-content-between align-items-center">
                           <a href="<?php the_permalink(); ?>"><?php echo tp_kses($settings['tp_post_button']); ?></a>
                           <a href="<?php the_permalink(); ?>"><i class="flaticon-right-arrow"></i></a>
                        </div>
                        <?php endif; ?> 
                     </div>
                  </div>
               </div>
               <?php endwhile; wp_reset_query(); endif; ?>
            </div>
         </div>
      </div>

<?php else : 
   $black = $settings['tp_black_switch'] ? 'tp-black-mode black-bg' : ''; 
   ?>

      <div class="tp-blog-3-area pt-120 pb-90 tp-el-section <?php echo esc_attr($black); ?>">
         <div class="container">
            <div class="row">
                <?php if ($query->have_posts()) :
                    $i = 0.0;
                    while ($query->have_posts()) : 
                    $query->the_post();
                    global $post;
                    $categories = get_the_category($post->ID);
                    $author_id = get_the_author_meta('ID');
                    $author_avatar_url = get_avatar_url($author_id);
                    $i+=0.3;
                ?>
               <div class="col-xl-<?php echo esc_attr($settings['tp_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['tp_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['tp_col_for_tablet']); ?> col-<?php echo esc_attr($settings['tp_col_for_mobile']); ?> mb-30 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
                  <div class="tp-blog-3-item">
                     <div class="tp-blog-3-thumb p-relative">
                        <?php the_post_thumbnail(); ?>
                        <div class="tp-blog-3-icon">
                           <a href="<?php the_permalink(); ?>"><i class="flaticon-right-arrow"></i></a>
                        </div>
                     </div>
                     <div class="tp-blog-3-content text-center z-index">
                        <div class="tp-blog-meta pb-10">
                           <span><i class="fa-light fa-circle-user"></i>By <?php echo ucwords(get_the_author()); ?></span>

                            <?php if(!empty($categories[0]->name)) : ?>
                            <span><a href="<?php echo esc_url(get_category_link($categories[0]->term_id)); ?>"><i class="flaticon-price-tag"></i> <?php echo esc_html($categories[0]->name); ?></a></span>
                            <?php endif; ?>
                        </div>
                        <h4 class="tp-blog-3-title"><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), $settings['tp_blog_title_word'], ''); ?></a></h4>

                        <?php if (!empty($settings['tp_post_content'])):
                            $tp_post_content_limit = (!empty($settings['tp_post_content_limit'])) ? $settings['tp_post_content_limit'] : '';
                                ?>
                        <p class="tp-el-rep-des"><?php print wp_trim_words(get_the_excerpt(get_the_ID()), $tp_post_content_limit, ''); ?></p>
                        <?php endif; ?>

                     </div>
                  </div>
               </div>
               <?php endwhile; wp_reset_query(); endif; ?>


                <?php if($settings['tp_post_pagination'] == 'yes' && '-1' != $settings['posts_per_page']) :?>
                <div class="basic-pagination mt-30">
                    <?php
                        $big = 999999999;

                        if (get_query_var('paged')) {
                            $paged = get_query_var('paged');
                        } else if (get_query_var('page')) {
                            $paged = get_query_var('page');
                        } else {
                            $paged = 1;
                        }

                        echo paginate_links( array(
                            'base'       => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
                            'format'     => '?paged=%#%',
                            'current'    => $paged,
                            'total'      => $query->max_num_pages,
                            'type'       =>'list',
                            'prev_text'  =>'<i>
                                                      <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                         <path d="M11 6H1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                         <path d="M6 11L1 6L6 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                      </svg>
                                                   </i> Prev Page',
                            'next_text'  =>'Next page <i>
                                                      <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                         <path d="M1 6H11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                         <path d="M6 11L11 6L6 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                      </svg>
                                                   </i>',
                            'show_all'   => false,
                            'end_size'   => 1,
                            'mid_size'   => 4,
                        ) );
                        ?>
                </div>
                <?php endif; ?>
            </div>
         </div>
      </div>

<?php endif;  
	}

}

$widgets_manager->register( new TP_Blog_Post() );