<?php
    namespace TPCore\Widgets;
?>

<div class="tpoffcanvas-area">
   <div class="tpoffcanvas">
      <div class="tpoffcanvas__close-btn">
         <button class="close-btn"><i class="fal fa-times"></i></button>
      </div>
      <?php if(!empty($tp_side_logo)) : ?>
      <div class="tpoffcanvas__logo">
         <a href="<?php print esc_url( home_url( '/' ) );?>">
            <img  style="width:<?php echo $settings['tp_logo_size']; ?>px" src="<?php echo esc_url($tp_side_logo); ?>" alt="<?php echo esc_attr($tp_side_logo_alt); ?>">
         </a>
      </div>
      <?php endif; ?>
      <?php if(!empty($settings['tp_side_content'])) : ?>
      <div class="tpoffcanvas__title">
         <p><?php echo esc_html($settings['tp_side_content']); ?></p>
      </div>
      <?php endif; ?>

      <div class="tp-main-menu-mobile d-xl-none"></div>

      <div class="tpoffcanvas__contact-info">
         <div class="tpoffcanvas__contact-title">
            <h5><?php echo esc_html__('Contact us','tpcore'); ?> </h5>
         </div>
         <ul>
         <?php if(!empty($settings['tp_side_address'])) : ?>
            <li>
               <i class="fa-light fa-location-dot"></i>
               <a href="<?php echo esc_html($settings['tp_side_address_url']); ?>" target="_blank"><?php echo esc_html($settings['tp_side_address']); ?></a>
            </li>
            <?php endif; ?>
            <?php if(!empty($settings['tp_ofc_email'])) : ?>
            <li>
               <i class="fas fa-envelope"></i>
               <a href="mailto:<?php echo esc_attr($settings['tp_ofc_email']); ?>"><?php echo tp_kses($settings['tp_ofc_email']); ?></a>
            </li>
            <?php endif; ?>
            <?php if(!empty($settings['tp_ofc_phone'])) : ?>
            <li>
               <i class="fal fa-phone-alt"></i>
               <a href="tel:<?php echo esc_attr($settings['tp_ofc_phone']); ?>"><?php echo esc_html($settings['tp_ofc_phone']); ?></a>
            </li>
            <?php endif; ?>
         </ul>
      </div>

      <?php if(!empty($settings['tp_ofc_subscribe'])) : ?>
      <div class="tpoffcanvas__input">
         <div class="tpoffcanvas__input-title">
            <h4><?php echo esc_html__('Get UPdate','tpcore'); ?></h4>
         </div> 
         <?php echo do_shortcode($settings['tp_ofc_subscribe']); ?>
      </div>
      <?php endif; ?>

      <div class="tpoffcanvas__social">
         <div class="social-icon">
         <?php foreach($settings['tp_ofc_social_list'] as $item) : if(!empty($item['tp_ofc_social_link'])) : ?>
            <a class="tp-el-off-social" href="<?php echo esc_url($item['tp_ofc_social_link']); ?>">
               <?php if($item['tp_box_icon_type'] == 'icon') : ?>
                  <?php if (!empty($item['tp_box_icon']) || !empty($item['tp_box_selected_icon']['value'])) : ?>
                  <?php tp_render_icon($item, 'tp_box_icon', 'tp_box_selected_icon'); ?>
                  <?php endif; ?>
               <?php elseif( $item['tp_box_icon_type'] == 'image' ) : ?>
                  <?php if (!empty($item['tp_box_icon_image']['url'])): ?>
                  <img src="<?php echo $item['tp_box_icon_image']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($item['tp_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                  <?php endif; ?>
               <?php else : ?>
                  <?php if (!empty($item['tp_box_icon_svg'])): ?>
                  <?php echo $item['tp_box_icon_svg']; ?>
                  <?php endif; ?>
               <?php endif; ?>
            </a>
            <?php endif; endforeach; ?>
         </div>
      </div>
   </div>
</div>
<div class="body-overlay"></div>
