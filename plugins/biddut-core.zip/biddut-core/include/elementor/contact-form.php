<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Contact_Form extends Widget_Base {

	 use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-contact-form';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Contact Form', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}


    public function get_tp_contact_form(){
        if ( ! class_exists( 'WPCF7' ) ) {
            return;
        }
        $tp_cfa         = array();
        $tp_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
        $tp_forms       = get_posts( $tp_cf_args );
        $tp_cfa         = ['0' => esc_html__( 'Select Form', 'tpcore' ) ];
        if( $tp_forms ){
            foreach ( $tp_forms as $tp_form ){
                $tp_cfa[$tp_form->ID] = $tp_form->post_title;
            }
        }else{
            $tp_cfa[ esc_html__( 'No contact form found', 'tpcore' ) ] = 0;
        }
        return $tp_cfa;
    }


	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
		$this->register_controls_section();
		$this->style_tab_content();
	}	

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
        
        $this->tp_section_title_render_controls('contact', 'Section Title', 'Sub Title', 'your title here', 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', ['layout-1', 'layout-3']);

        $this->start_controls_section(
            'tpcore_contact',
            [
                'label' => esc_html__('Contact Form', 'tpcore'),
            ]
        );

        $this->add_control(
            'tpcore_select_contact_form',
            [
                'label'   => esc_html__( 'Select Form', 'tpcore' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '0',
                'options' => $this->get_tp_contact_form(),
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'contact_image_section',
            [
                'label' => esc_html__( 'Image', 'textdomain' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => [
                    'tp_design_style' => 'layout-3'
                ]
            ]
        );

        $this->add_control(
            'contact_image',
            [
                'label' => esc_html__( 'Choose Image', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );


        $this->end_controls_section();

	}

    protected function style_tab_content(){
        $this->tp_section_style_controls('contact_section', 'Section Style', '.ele-section');
        $this->tp_basic_style_controls('section_subtitle', 'Section - Subtitle', '.tp-el-subtitle', ['layout-1', 'layout-2']);
        $this->tp_basic_style_controls('section_title', 'Section - Title', '.tp-el-title', ['layout-1', 'layout-2']);
        $this->tp_basic_style_controls('section_desc', 'Section - Description', '.tp-el-content', ['layout-1', 'layout-2']);
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ):
    $this->add_render_attribute('title_args', 'class', 'contact-form-title tp-el-title');
?>

 <div class="tp-order-form-area d-none d-md-block">
    <div class="container custom-container-2">
       <div class="tp-order-form-space wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
		    <?php if( !empty($settings['tpcore_select_contact_form']) ) : ?>
		    <?php echo do_shortcode( '[contact-form-7  id="'.$settings['tpcore_select_contact_form'].'"]' ); ?>
		    <?php else : ?>
		    <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'tpcore' ). '</p></div>'; ?>
		    <?php endif; ?>                 
       </div>
    </div>
 </div>

<?php elseif ( $settings['tp_design_style']  == 'layout-3' ):
    $this->add_render_attribute('title_args', 'class', 'tp-contact-2-title tp-el-title');


    // contact_image
    if ( !empty($settings['contact_image']['url']) ) {
        $contact_image = !empty($settings['contact_image']['id']) ? wp_get_attachment_image_url( $settings['contact_image']['id'], 'full') : $settings['contact_image']['url'];
        $contact_image_alt = get_post_meta($settings["contact_image"]["id"], "_wp_attachment_image_alt", true);
    }
?>

<div class="tp-contact-2-area tp-contact-2-bg fix p-relative">
 <div class="tp-contact-2-shape-1 d-none d-lg-block">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/contact/shape-2-1.png" alt="">
 </div>
 <div class="tp-contact-2-shape-2 d-none d-lg-block">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/contact/shape-2-2.png" alt="">
 </div>
 <div class="tp-contact-2-shape-3 d-none d-lg-block">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/contact/shape-2-3.png" alt="">
 </div>
 <div class="tp-contact-2-shape-4 d-none d-xxl-block">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/contact/shape-2-4.png" alt="">
 </div>
 <div class="container">
    <div class="row">
       <div class="col-xl-6 col-lg-6 offset-xl-6 offset-lg-6">
          <div class="tp-contact-2-item z-index">
             <div class="tp-contact-2-section-box mb-40">
		        <?php if ( !empty($settings['tp_contact_sub_title']) ) : ?>
		            <span class="tp-contact-2-subtitle tp-el-subtitle"><?php echo tp_kses( $settings['tp_contact_sub_title'] ); ?></span>
		        <?php endif; ?>
		        <?php
		            if ( !empty($settings['tp_contact_title' ]) ) :
		                printf( '<%1$s %2$s>%3$s</%1$s>',
		                tag_escape( $settings['tp_contact_title_tag'] ),
		                $this->get_render_attribute_string( 'title_args' ),
		                tp_kses( $settings['tp_contact_title' ] )
		                );
		            endif;
		        ?>
		        <?php if ( !empty($settings['tp_contact_description']) ) : ?>
		        <p class="tp-el-content"><?php echo tp_kses( $settings['tp_contact_description'] ); ?></p>
		        <?php endif; ?>
             </div>

		    <?php if( !empty($settings['tpcore_select_contact_form']) ) : ?>
		    <?php echo do_shortcode( '[contact-form-7  id="'.$settings['tpcore_select_contact_form'].'"]' ); ?>
		    <?php else : ?>
		    <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'tpcore' ). '</p></div>'; ?>
		    
		    <?php endif; ?> 
          </div>
       </div>
    </div>
 </div>
 <?php if(!empty($contact_image)) : ?>
 <div class="tp-contact-2-thumb">
    <img src="<?php echo esc_url($contact_image); ?>" alt="<?php echo esc_attr($contact_image_alt); ?>">
 </div>
 <?php endif; ?> 
</div>


<?php else :
    $this->add_render_attribute('title_args', 'class', 'tp-contact-form-title tp-el-title');
?>


	<div class="tp-contact-form-border ele-section">
		<div class="tp-step-section-box tp-el-section ele-content-align">
        <?php if ( !empty($settings['tp_contact_sub_title']) ) : ?>
            <span class="tp-section-subtitle tp-el-subtitle"><?php echo tp_kses( $settings['tp_contact_sub_title'] ); ?></span>
        <?php endif; ?>
        <?php
            if ( !empty($settings['tp_contact_title' ]) ) :
                printf( '<%1$s %2$s>%3$s</%1$s>',
                tag_escape( $settings['tp_contact_title_tag'] ),
                $this->get_render_attribute_string( 'title_args' ),
                tp_kses( $settings['tp_contact_title' ] )
                );
            endif;
        ?>
        <?php if ( !empty($settings['tp_contact_description']) ) : ?>
        <p class="tp-el-content"><?php echo tp_kses( $settings['tp_contact_description'] ); ?></p>
        <?php endif; ?>
    	</div>


	    <?php if( !empty($settings['tpcore_select_contact_form']) ) : ?>
	    <?php echo do_shortcode( '[contact-form-7  id="'.$settings['tpcore_select_contact_form'].'"]' ); ?>
	    <?php else : ?>
	    <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'tpcore' ). '</p></div>'; ?>
	    <?php endif; ?>
      </div>


<?php endif; 
	}
}

$widgets_manager->register( new TP_Contact_Form() );