<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Portfolio_Info_List extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'tp-portfolio-info-list';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Portfolio Info List', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'tpcore' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  
    protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // Service group
        $this->start_controls_section(
            'tp_services',
            [
                'label' => esc_html__('Portfolio Info List', 'tpcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'tp_info_sub_title',
            [
                'label' => esc_html__('Sub title', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Label:', 'tpcore'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'tp_info_title',
            [
                'label' => esc_html__('Title', 'tpcore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Liza Olivares', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_info_list',
            [
                'label' => esc_html__('Footer - List', 'tpcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tp_info_title' => esc_html__('Title 1', 'tpcore'),
                    ],
                    [
                        'tp_info_title' => esc_html__('Title 2', 'tpcore')
                    ],
                    [
                        'tp_info_title' => esc_html__('Title 3', 'tpcore')
                    ]
                ],
                'title_field' => '{{{ tp_info_title }}}',
            ]
        );
        $this->end_controls_section();

    }

    protected function style_tab_content(){
        $this->tp_section_style_controls('footer_section', 'Section - Style', '.tp-el-section');
        $this->tp_basic_style_controls('section_heading', 'Section - Title', '.tp-el-heading');
        $this->tp_link_controls_style('footer_title', 'Links', '.tp-el-title');
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>

        <?php if ( $settings['tp_design_style']  == 'layout-2' ):
            $this->add_render_attribute('title_args', 'class', 'sectionTitle__big');
        ?>

        
        <?php else:
            $this->add_render_attribute('title_args', 'class', 'title');
        ?>

        <div class="project-details-customize">
        <div class="evn-related-info d-flex gap-4 flex-wrap align-items-center tp-el-section">
            <?php foreach ($settings['tp_info_list'] as $key => $item) : ?>
            <span><b><?php echo tp_kses($item['tp_info_sub_title']); ?></b><br><?php echo tp_kses($item['tp_info_title']); ?></span> 
            <?php endforeach; ?>                        
        </div>
        </div>


<?php endif;
    }
}

$widgets_manager->register( new TP_Portfolio_Info_List() );
