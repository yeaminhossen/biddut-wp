<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use TPCore\Elementor\Controls\Group_Control_TPBGGradient;
use TPCore\Elementor\Controls\Group_Control_TPGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Support extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'tp-support';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Support', 'tpcore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'tp-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'tpcore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'tpcore' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   
    protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // Service group
        $this->start_controls_section(
            'tp_services',
            [
                'label' => esc_html__('Support List', 'tpcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();


        $repeater->add_control(
            'tp_box_image',
            [
                'label' => esc_html__('Upload Icon Image', 'tpcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'tp_support_title', [
                'label' => esc_html__('Title', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'tpcore'),
                'label_block' => true,
            ]
        );

        
        $repeater->add_control(
            'tp_support_url', [
                'label' => esc_html__('URL', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('#', 'tpcore'),
                'label_block' => true,
            ]
        );
        
        $this->add_control(
            'tp_support_list',
            [
                'label' => esc_html__('Services - List', 'tpcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tp_support_title' => esc_html__('Business Stratagy', 'tpcore'),
                    ],
                    [
                        'tp_support_title' => esc_html__('Website Development', 'tpcore')
                    ],
                    [
                        'tp_support_title' => esc_html__('Marketing & Reporting', 'tpcore')
                    ]
                ],
                'title_field' => '{{{ tp_support_title }}}',
            ]
        );
        
        $this->end_controls_section();

        // section column
        $this->tp_columns('col', ['layout-1']);

    }

    // style_tab_content
    protected function style_tab_content(){
        $this->tp_section_style_controls('services_section', 'Section - Style', '.tp-el-section');
        $this->tp_basic_style_controls('section_subtitle', 'Section - Subtitle', '.tp-el-subtitle',[ 'layout-1', 'layout-3', 'layout-5']);
        $this->tp_basic_style_controls('section_title', 'Section - Title', '.tp-el-title',[ 'layout-1', 'layout-3', 'layout-5']);
        $this->tp_basic_style_controls('section_desc', 'Section - Description', '.tp-el-content',[ 'layout-1', 'layout-3', 'layout-5']);

        # repeater 
        $this->tp_icon_style('rep_icon_style', 'Repeater Icon/Image/SVG', '.tp-el-rep-icon', ['layout-1', 'layout-2', 'layout-3', 'layout-5', 'layout-6']);
        $this->tp_basic_style_controls('rep_subtitle_style', 'Repeater Subtitle', '.tp-el-rep-subtitle', ['layout-1', 'layout-4']);
        $this->tp_basic_style_controls('rep_title_style', 'Repeater Title', '.tp-el-rep-title', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6', 'layout-7']);
        $this->tp_basic_style_controls('rep_des_style', 'Repeater Description', '.tp-el-rep-des', ['layout-2', 'layout-3', 'layout-5', 'layout-6', 'layout-7']);
        $this->tp_link_controls_style('rep_btn_style', 'Repeater Button', '.tp-el-rep-btn', ['layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6', 'layout-7']);
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ) : ?>


<?php else:
    $this->add_render_attribute('title_args', 'class', 'tp-section-title tp-el-title');
?>

      <div class="tp-faq-area pt-120 tp-el-section">
         <div class="container">
            <div class="row">
                <?php foreach ($settings['tp_support_list'] as $key => $item) :
                    // thumbnail
                    if ( !empty($item['tp_box_image']['url']) ) {
                        $tp_box_image = !empty($item['tp_box_image']['id']) ? wp_get_attachment_image_url( $item['tp_box_image']['id'], 'full') : $item['tp_box_image']['url'];
                        $tp_box_image_alt = get_post_meta($item["tp_box_image"]["id"], "_wp_attachment_image_alt", true);
                    }

                ?>
               <div class="col-xl-<?php echo esc_attr($settings['tp_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['tp_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['tp_col_for_tablet']); ?> col-<?php echo esc_attr($settings['tp_col_for_mobile']); ?> wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
                  <div class="tp-faq-item p-relative">
                     <div class="tp-faq-thumb-box">
                        <img src="<?php echo esc_url($tp_box_image); ?>" alt="">
                     </div>
                     <div class="tp-faq-thumb-text">
                        <h4 class="tp-faq-title"><?php echo tp_kses($item['tp_support_title' ]); ?></h4>
                        <?php if ( !empty($item['tp_support_url']) ) : ?>
                        <a href="<?php echo tp_kses($item['tp_support_url' ]); ?>"><i class="flaticon-right-arrow"></i></a>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
           <?php endforeach; ?>
            </div>
         </div>
      </div>


<?php endif; 
    }
}

$widgets_manager->register( new TP_Support() ); 