<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use TPCore\Elementor\Controls\Group_Control_TPBGGradient;
use TPCore\Elementor\Controls\Group_Control_TPGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Newsletter extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-newsletter';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Newsletter', 'tp-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tp-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  


	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tp-core'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tp-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tp-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->tp_section_title_render_controls('newsletter', 'Section Title', 'Sub Title', 'your title here', 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', ['layout-1']);

        // subscriber form
        $this->start_controls_section(
            'tp_subs_sec',
            [
                'label' => esc_html__('Subscriber Section', 'tp-core'),
            ]
        );
        
        $this->add_control(
        'form_shortcode',
            [
            'label'   => esc_html__( 'Newsletter Shortcode', 'tpcore' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_shape_switch',
            [
                'label' => esc_html__( 'Active Shape', 'tp-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tp-core' ),
                'label_off' => esc_html__( 'Hide', 'tp-core' ),
                'return_value' => 'yes',
                'default' => 0,
            ]
        );


        $this->end_controls_section();

        
	}

    // style_tab_content
    protected function style_tab_content(){
        $this->tp_section_style_controls('newsletter_section', 'Section - Style', '.tp-el-section');
        $this->tp_basic_style_controls('section_subtitle', 'Section - Subtitle', '.tp-el-subtitle', ['layout-1', 'layout-2', 'layout-3']);
        $this->tp_basic_style_controls('section_title', 'Section - Title', '.tp-el-title', ['layout-1', 'layout-2', 'layout-3']);
        $this->tp_basic_style_controls('section_desc', 'Section - Description', '.tp-el-content', ['layout-1', 'layout-2', 'layout-3']);
        $this->tp_basic_style_controls('cat_heading', 'Category Heading', '.tp-el-cat-head', ['layout-1', 'layout-3']);
        $this->tp_link_controls_style('cat_list', 'Category List', '.tp-el-cat-list', ['layout-1', 'layout-3']);
        # repeater 
        $this->tp_icon_style('rep_icon_style', 'Repeater Icon/Image/SVG', '.tp-el-rep-icon', 'layout-2');
        $this->tp_basic_style_controls('rep_title_style', 'Repeater Title', '.tp-el-rep-title', 'layout-2');
        $this->tp_basic_style_controls('rep_des_style', 'Repeater Description', '.tp-el-rep-des', 'layout-2');
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ) : 
    $this->add_render_attribute('title_args', 'class', 'cta-inner-title tp-el-title');    
?>


<?php else:
    $this->add_render_attribute('title_args', 'class', 'tp-cta-title tp-el-title');
    $shape_class = $settings['tp_shape_switch'] ? 'tp-cta-bg' : '';
?>

  <div class="tp-cta-area tp-cta-wrap-box <?php echo esc_attr($shape_class); ?>  fix p-relative tp-el-section">
     <div class="tp-cta-shape d-none d-lg-block">
        <img src="<?php echo get_template_directory_uri(); ?> /assets/img/cta/shape-1-1.png" alt="">
     </div>
     <div class="container">
        <div class="tp-cta-wrap theme-bg">
           <div class="row">
              <div class="col-xl-6 col-lg-6">
                 <div class="tp-cta-left-box">
                    <?php if ( !empty($settings['tp_newsletter_sub_title']) ) : ?>
                    <span class="tp-section-subtitle tp-el-subtitle"><?php echo tp_kses($settings['tp_newsletter_sub_title']); ?></span>
                    <?php endif; ?>
                    <?php
                    if ( !empty($settings['tp_newsletter_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['tp_newsletter_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        tp_kses( $settings['tp_newsletter_title' ] )
                        );
                    endif;
                    ?>
                    <?php if ( !empty($settings['tp_newsletter_description']) ) : ?>
                    <p class="tp-el-content"><?php echo tp_kses( $settings['tp_newsletter_description'] ); ?></p>
                    <?php endif; ?>
                 </div>
              </div>
              <div class="col-xl-6 col-lg-6">
                 <div class="tp-cta-right-box p-relative">
                    <?php if( !empty($settings['form_shortcode']) ) : ?>
                    <?php echo do_shortcode( $settings['form_shortcode'] ); ?>
                    <?php else : ?>
                    <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please insert shortcode.', 'tpcore' ). '</p></div>'; ?>
                    <?php endif; ?>
                 </div>
              </div>
           </div>
        </div>
     </div>
  </div>


<?php endif; 
        
	}
}

$widgets_manager->register( new TP_Newsletter() );