<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Typography;
Use \Elementor\Core\Schemes\Typography;
use \Elementor\Group_Control_Background;
use TPCore\Elementor\Controls\Group_Control_TPBGGradient;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Fact extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-fact';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Fact', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // fact group
        $this->start_controls_section(
            'tp_fact',
            [
                'label' => esc_html__('Fact List', 'tpcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'tpcore' ),
                    'style_2' => __( 'Style 2', 'tpcore' ),
                    'style_3' => __( 'Style 3', 'tpcore' ),
                    'style_4' => __( 'Style 4', 'tpcore' ),
                    'style_5' => __( 'Style 5', 'tpcore' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'tp_box_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'tpcore'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'tpcore'),
                    'icon' => esc_html__('Icon', 'tpcore'),
                    'svg' => esc_html__('SVG', 'tpcore'),
                ],
            ]
        );


        $repeater->add_control(
            'box_icon',
            [
                'label' => esc_html__( 'Icon', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'fa-solid',
                ],
                'recommended' => [
                    'fa-solid' => [
                        'circle',
                        'dot-circle',
                        'square-full',
                    ],
                    'fa-regular' => [
                        'circle',
                        'dot-circle',
                        'square-full',
                    ],
                ],
                'condition' => [
                    'tp_box_icon_type' => 'icon',
                ],
            ]
        );

        $repeater->add_control(
            'tp_box_icon_image',
            [
                'label' => esc_html__('Upload Icon Image', 'tpcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_box_icon_type' => 'image',
                ],
            ]
        );

        $repeater->add_control(
            'tp_box_icon_svg',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'tpcore'),
                'condition' => [
                    'tp_box_icon_type' => 'svg',
                ],
            ]
        ); 

        $repeater->add_control(
            'tp_fact_number', [
                'label' => esc_html__('Number', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('17', 'tpcore'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'tp_fact_after',
            [
                'label' => esc_html__('After Content', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'tp_fact_title',
            [
                'label' => esc_html__('Title', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Food', 'tpcore'),
                'label_block' => true,
            ]
        );
        
        $this->add_control(
            'tp_fact_list',
            [
                'label' => esc_html__('Fact - List', 'tpcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tp_fact_number' => esc_html__('600', 'tpcore'),
                        'tp_fact_title' => esc_html__('Business', 'tpcore'),
                    ],
                    [
                        'tp_fact_number' => esc_html__('700', 'tpcore'),
                        'tp_fact_title' => esc_html__('Website', 'tpcore')
                    ],
                    [
                        'tp_fact_number' => esc_html__('800', 'tpcore'),
                        'tp_fact_title' => esc_html__('Marketing', 'tpcore')
                    ]
                ],
                'title_field' => '{{{ tp_fact_title }}}',
            ]
        );
        $this->end_controls_section();

        // section column
        $this->tp_columns('col', ['layout-1', 'layout-2', 'layout-5']);

	}

    // style_tab_content
    protected function style_tab_content(){
        $this->tp_section_style_controls('fact_section', 'Section - Style', '.tp-el-section');
        # repeater 
        $this->tp_icon_style('rep_icon_style', 'Repeater Icon/Image/SVG', '.tp-el-rep-icon', ['layout-2', 'layout-3', 'layout-4', 'layout-5']);
        $this->tp_link_controls_style('rep_num_style', 'Repeater Number', '.tp-el-rep-num', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5']);
        $this->tp_basic_style_controls('rep_title_style', 'Repeater Title', '.tp-el-rep-title', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5']);
        $this->tp_progressbar_style_controls('rep_progress_style', 'Repeater Progressbar', '.tp-el-rep-progress', 'layout-4');
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ): ?>
      <div class="tp-funfact-4-area pt-120 pb-60 tp-el-section">
         <div class="container">
            <div class="row g-0">
               <?php foreach ($settings['tp_fact_list'] as $key => $item) : ?>     
               <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 mb-30">
                  <div class="tp-funfact-4-item text-center">
                     <div class="tp-funfact-4-icon">
                        <?php if($item['tp_box_icon_type'] == 'icon') : ?>
                        <span class="tp-el-rep-icon">
                        <?php \Elementor\Icons_Manager::render_icon( $item['box_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        </span>
                        <?php elseif($item['tp_box_icon_type'] == 'image') : ?>
                        <span class="tp-el-rep-icon">
                            <img src="<?php echo $item['tp_box_icon_image']['url']; ?>" alt="">
                        </span>
                        <?php else: ?>
                        <span class="tp-el-rep-icon">
                            <?php echo $item['tp_box_icon_svg']; ?>
                        </span>
                        <?php endif; ?>
                     </div>
                     <div class="tp-funfact-4-content p-relative">
                        <h5 class="tp-funfact-4-number purecounter" data-purecounter-duration="1" data-purecounter-end="<?php echo tp_kses($item['tp_fact_number']); ?>">0</h5>
                        <div class="tp-funfact-4-text">
                           <span class="tp-el-rep-title"><?php echo tp_kses($item['tp_fact_title']); ?></span>
                        </div>
                     </div>
                  </div>
               </div>
               <?php endforeach; ?>
            </div>
         </div>
      </div>

<?php else : ?>

      <div class="tp-funfact-area fix p-relative grey-bg pt-180 pb-85 tp-el-section">
         <div class="tp-funfact-shape-1">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/funfact/shape-1-1.png" alt="">
         </div>
         <div class="tp-funfact-shape-2 d-none d-xl-block">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/funfact/shape-1-2.png" alt="">
         </div>
         <div class="container">
            <div class="row">
                <?php foreach ($settings['tp_fact_list'] as $key => $item) : ?>
               <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 mb-30">
                  <div class="tp-funfact-item text-center">
                     <div class="tp-funfact-icon">
                        <?php if($item['tp_box_icon_type'] == 'icon') : ?>
                        <span class="tp-el-rep-icon">
                        <?php \Elementor\Icons_Manager::render_icon( $item['box_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        </span>
                        <?php elseif($item['tp_box_icon_type'] == 'image') : ?>
                        <span class="tp-el-rep-icon">
                            <img src="<?php echo $item['tp_box_icon_image']['url']; ?>" alt="">
                        </span>
                        <?php else: ?>
                        <span class="tp-el-rep-icon">
                            <?php echo $item['tp_box_icon_svg']; ?>
                        </span>
                        <?php endif; ?>
                     </div>
                     <div class="tp-funfact-content">
                        <h5 class="tp-funfact-number"><i class="purecounter" data-purecounter-duration="1"
                              data-purecounter-end="<?php echo tp_kses($item['tp_fact_number']); ?>">0</i><?php echo $item['tp_fact_after'] ? tp_kses($item['tp_fact_after']) : NULL; ?></h5>
                        <span class="tp-el-rep-title"><?php echo tp_kses($item['tp_fact_title']); ?></span>
                     </div>
                  </div>
               </div>
               <?php endforeach; ?> 
            </div>
         </div>
      </div>

<?php endif; 
        
	}
}

$widgets_manager->register( new TP_Fact() );