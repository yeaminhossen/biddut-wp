<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Blog_Post_New extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'blog-post-new';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Blog Post New', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                    'layout-3' => esc_html__('Layout 3', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
        
        
      $this->start_controls_section(
			'harry_post_section',
			[
				'label' => esc_html__( 'Blog Post', 'harry-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'post_per_page',
			[
				'label' => esc_html__( 'Post Per Page', 'harry-core' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 3,
			]
		);

		$this->add_control(
			'cat_list',
			[
				'label' => esc_html__( 'Category Include', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple' => true,
				'options' => post_cat(),
			]
		);

		$this->add_control(
			'cat_exclude',
			[
				'label' => esc_html__( 'Category Exclude', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple' => true,
				'options' => post_cat(),
			]
		);

		$this->add_control(
			'post_include',
			[
				'label' => esc_html__( 'Post Include', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple' => true,
				'options' => get_all_post(),
			]
		);

		$this->add_control(
			'post_exclude',
			[
				'label' => esc_html__( 'Post Exclude', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple' => true,
				'options' => get_all_post(),
			]
		);

		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Order', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'ASC',
				'options' => [
					'ASC' => esc_html__( 'ASC', 'textdomain' ),
					'DFESC'  => esc_html__( 'DESC', 'textdomain' ),
				],
			]
		);

		$this->add_control(
			'order_by',
			[
				'label' => esc_html__( 'Order By', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'name' => esc_html__( 'Name', 'textdomain' ),
					'date'  => esc_html__( 'Date', 'textdomain' ),
					'title'  => esc_html__( 'Title', 'textdomain' ),
					'rand'  => esc_html__( 'Rand', 'textdomain' ),
					'id'  => esc_html__( 'ID', 'textdomain' ),
				],
			]
		);


		$this->end_controls_section();


        // section column
        $this->tp_columns('col', ['layout-1', 'layout-3', 'layout-4', 'layout-7']);

        // layout Panel
        $this->start_controls_section(
            'add_features_sec',
            [
                'label' => esc_html__('Additional Features', 'tpcore'),
            ]
        );
        $this->add_control(
        'tp_post_pagination',
        [
            'label'        => esc_html__( 'Pagination On/Off', 'tpcore' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'tpcore' ),
            'label_off'    => esc_html__( 'Hide', 'tpcore' ),
            'return_value' => 'yes',
            'default'      => '0',
        ]
        );

        $this->end_controls_section();

	}

    // style_tab_content
    protected function style_tab_content(){
		$this->tp_section_style_controls('blog_section', 'Section Style', '.tp-el-section');
        # repeater 
        $this->tp_link_controls_style('rep_cat_style', 'Blog Category', '.tp-el-rep-cat', ['layout-1', 'layout-2', 'layout-4', 'layout-5', 'layout-6', 'layout-7']);
        $this->tp_link_controls_style('rep_title_style', 'Blog Title', '.tp-el-rep-title', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6', 'layout-7']);
        $this->tp_basic_style_controls('rep_des_style', 'Blog Description', '.tp-el-rep-des', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6', 'layout-7']);
        $this->tp_link_controls_style('rep_btn_style', 'Blog Button', '.tp-el-rep-btn', ['layout-1', 'layout-2', 'layout-6']);
        $this->tp_icon_style('rep_avatar_style', 'Blog Avatar Icon/Image/SVG', '.tp-el-rep-avatar', 'layout-1');
        $this->tp_basic_style_controls('rep_ava_name_style', 'Blog Avatar Name', '.tp-el-rep-ava-name', ['layout-1', 'layout-4', 'layout-5', 'layout-6', 'layout-7']);
        $this->tp_basic_style_controls('rep_date_style', 'Blog Date', '.tp-el-rep-date', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6', 'layout-7']);
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$args = array(
			'post_type' => 'post',
			'order' => $settings['order'],
			'orderby' => $settings['order_by'],
			'posts_per_page' => !empty($settings['post_per_page']) ? $settings['post_per_page'] : -1,
			'post__in'=> $settings['post_include'],
			'post__not_in'=> $settings['post_exclude'],
		);

		if(!empty($settings['cat_list'] )){
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'category',
					'field' => 'slug',
					'terms' => $settings['cat_list'],
					'operator' => 'IN',
				),
			);
		}
		if( !empty($settings['cat_exclude']) ){
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'category',
					'field' => 'slug',
					'terms' => $settings['cat_exclude'],
					'operator' => 'NOT IN',
				),
			);
		}

		$query = new \WP_Query( $args );

        ?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ) : ?>



<?php else : ?>

   <div class="tp-blog-3-area pt-120 pb-90">
         <div class="container">
            <div class="row">
                  <?php if ( $query->have_posts() ) : ?>
                  <?php while ( $query->have_posts() ) : $query->the_post();
                     $categories = get_the_category(get_the_ID());
                  ?>	
                  <div class="col-xl-4 col-lg-4 col-md-6 mb-30 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
                     <div class="tp-blog-3-item">
                        <div class="tp-blog-3-thumb p-relative">
                           <?php the_post_thumbnail(); ?>
                           <div class="tp-blog-3-icon">
                              <a href="<?php the_permalink( ); ?>"><i class="flaticon-right-arrow"></i></a>
                           </div>
                        </div>
                        <div class="tp-blog-3-content text-center z-index">
                           <div class="tp-blog-meta pb-10">
                              <span><i class="fa-light fa-circle-user"></i>By thempure</span>
                              <span><i class="flaticon-price-tag"></i>Repair</span>
                           </div>
                           <h4 class="tp-blog-3-title"><a href="<?php the_permalink( ); ?>"><?php the_title(); ?></a></h4>
                        </div>
                     </div>
                  </div>
                  <?php endwhile; wp_reset_postdata(); endif;  ?> 
               </div>
            </div>
         </div>
      </div>



<?php endif;  
	}

}

$widgets_manager->register( new TP_Blog_Post_New() );