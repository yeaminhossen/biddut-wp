<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_Featres_List extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-features-list';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Features List', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   
	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'), 
                    'layout-2' => esc_html__('Layout 2', 'tpcore'), 
                ],
                'default' => 'layout-1',
            ]
        );

        $this->add_control(
            'tp_black_switch',
            [
                'label'        => esc_html__( 'Black On/Off', 'tpcore' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'tpcore' ),
                'label_off'    => esc_html__( 'Hide', 'tpcore' ),
                'return_value' => 'yes',
                'default'      => '0',
                'condition' => [
                    'tp_design_style' => 'layout-1'
                ]
            ]
        );

        $this->end_controls_section();

        // Process group
        $this->start_controls_section(
            'tp_features',
            [
                'label' => esc_html__('Features List', 'tpcore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'tpcore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'tpcore' ),
                    'style_2' => __( 'Style 2', 'tpcore' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'tp_box_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'tpcore'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'tpcore'),
                    'icon' => esc_html__('Icon', 'tpcore'),
                    'svg' => esc_html__('SVG', 'tpcore'),
                ],
            ]
        );


        $repeater->add_control(
            'box_icon',
            [
                'label' => esc_html__( 'Icon', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'fa-solid',
                ],
                'recommended' => [
                    'fa-solid' => [
                        'circle',
                        'dot-circle',
                        'square-full',
                    ],
                    'fa-regular' => [
                        'circle',
                        'dot-circle',
                        'square-full',
                    ],
                ],
                'condition' => [
                    'tp_box_icon_type' => 'icon',
                ],
            ]
        );

        $repeater->add_control(
            'tp_box_icon_image',
            [
                'label' => esc_html__('Upload Icon Image', 'tpcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_box_icon_type' => 'image',
                ],
            ]
        );

        $repeater->add_control(
            'tp_box_icon_svg',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'tpcore'),
                'condition' => [
                    'tp_box_icon_type' => 'svg',
                ],
            ]
        );

        $repeater->add_control(
            'tp_features_title', [
                'label' => esc_html__('Title', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Process Title', 'tpcore'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'tp_features_text', [
                'label' => esc_html__('Content', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Content here..', 'tpcore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'tp_features_list',
            [
                'label' => esc_html__('Features - List', 'tpcore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tp_process_title' => esc_html__('Discover', 'tpcore'),
                    ],
                    [
                        'tp_process_title' => esc_html__('Define', 'tpcore')
                    ],
                    [
                        'tp_process_title' => esc_html__('Develop', 'tpcore')
                    ],
                ],
                'title_field' => '{{{ tp_features_title }}}',
            ]
        );
        
        $this->end_controls_section();

        // shape
        $this->start_controls_section(
        'tp_shape',
            [
                'label' => esc_html__( 'Shape Section', 'tpcore' ),
                'condition' => [
                    'tp_design_style' => ['layout-1', 'layout-2', 'layout-3']
                ]
            ]
        );

        $this->add_control(
        'tp_shape_switch',
        [
            'label'        => esc_html__( 'Shape On/Off', 'tpcore' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'tpcore' ),
            'label_off'    => esc_html__( 'Hide', 'tpcore' ),
            'return_value' => 'yes',
            'default'      => '0',
        ]
        );

        $this->add_control(
            'tp_shape_image_1',
            [
                'label' => esc_html__( 'Choose Shape Image 1', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_shape_switch' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'tp_shape_image_2',
            [
                'label' => esc_html__( 'Choose Shape Image 2', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_shape_switch' => 'yes',
                    'tp_design_style' => ['layout-2', 'layout-3']
                ]
            ]
        );

        $this->add_control(
            'tp_shape_image_3',
            [
                'label' => esc_html__( 'Choose Shape Image 3', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_shape_switch' => 'yes',
                    'tp_design_style' => 'layout-2'
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'shape_image_size', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                'exclude' => ['custom'],
                'condition' => [
                    'tp_shape_switch' => 'yes'
                ]
            ]
        );
        
        $this->end_controls_section();

	}

    // style_tab_content
    protected function style_tab_content(){
        $this->tp_section_style_controls('process_section', 'Section - Style', '.tp-el-section');

        $this->tp_basic_style_controls('section_subtitle', 'Features - Title', '.tp-el-subtitle');

        $this->tp_basic_style_controls('section_fea_content', 'Features - Content', '.tp-el-content');

        // $this->tp_basic_style_controls('section_title', 'Section - Title', '.tp-el-title', ['layout-1', 'layout-2', 'layout-3']);
        // $this->tp_basic_style_controls('section_desc', 'Section - Description', '.tp-el-content', ['layout-1', 'layout-2', 'layout-3']);

        // # repeater 
        // $this->tp_icon_style('rep_icon_style', 'Repeater Icon/Image/SVG', '.tp-el-rep-icon', ['layout-3', 'layout-4', 'layout-5', 'layout-6']);
        // $this->tp_link_controls_style('rep_num_style', 'Repeater Number', '.tp-el-rep-num', 'layout-1');
        // $this->tp_basic_style_controls('rep_subtitle_style', 'Repeater Subtitle', '.tp-el-rep-subtitle', ['layout-2', 'layout-3']);
        // $this->tp_basic_style_controls('rep_title_style', 'Repeater Title', '.tp-el-rep-title', ['layout-1', 'layout-2', 'layout-3', 'layout-4', 'layout-5', 'layout-6']);
        // $this->tp_basic_style_controls('rep_des_style', 'Repeater Description', '.tp-el-rep-des', ['layout-4', 'layout-5', 'layout-6']);
        // $this->tp_basic_style_controls('rep_addi_style', 'Repeater Additional Info', '.tp-el-rep-addi', 'layout-2');
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        
        ?>

<?php if ( $settings['tp_design_style']  == 'layout-2' ) : 
    $this->add_render_attribute('title_args', 'class', 'tpsection-title tpsection-title-white mb-15 tp-el-title');
?>
 <div class="tp-about-4-content d-flex align-items-center justify-content-between">
    <?php foreach ($settings['tp_features_list'] as $key => $item) : 
    $active = ($key == 2) ? 'active' : ''; 
    ?>
    <div class="tp-about-4-mission-box">
       <h4> 
        <?php if($item['tp_box_icon_type'] == 'icon') : ?>
        <span class="tp-el-rep-icon">
        <?php \Elementor\Icons_Manager::render_icon( $item['box_icon'], [ 'aria-hidden' => 'true' ] ); ?>
        </span>
        <?php elseif($item['tp_box_icon_type'] == 'image') : ?>
        <span class="tp-el-rep-icon">
            <img src="<?php echo $item['tp_box_icon_image']['url']; ?>" alt="">
        </span>
        <?php else: ?>
        <span class="tp-el-rep-icon">
            <?php echo $item['tp_box_icon_svg']; ?>
        </span>
        <?php endif; ?>

       <?php echo tp_kses($item['tp_features_title']); ?></h4>
        <?php if(!empty($item['tp_features_text'])) : ?>
        <p class="tp-el-content"><?php echo tp_kses($item['tp_features_text']); ?></p>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
 </div>


<?php else: 

$black = $settings['tp_black_switch'] ? 'tp-black-mode black-bg-3' : 'grey-bg'; 

?>


<div class="tp-feature-2-area  p-relative  pt-120 pb-90 tp-el-section <?php echo esc_attr($black); ?>">
 <div class="tp-feature-2-bg">
    <div class="tp-feature-2-shape-1 d-none d-xxl-block">
       <img src="<?php echo get_template_directory_uri(); ?>/assets/img/feature/shape-1-1.png" alt="">
    </div>
    <div class="container">
       <div class="row">
            <?php foreach ($settings['tp_features_list'] as $key => $item) : 
            $active = ($key == 2) ? 'active' : ''; 
            ?>
          <div class="col-xl-3 col-lg-4 col-md-6 mb-30 wow tpfadeUp" data-wow-duration=".9s" data-wow-delay=".7s">
             <div class="tp-feature-2-item <?php echo esc_attr($active); ?>">
                <div class="tp-feature-2-icon">
                    <?php if($item['tp_box_icon_type'] == 'icon') : ?>
                    <span class="tp-el-rep-icon">
                    <?php \Elementor\Icons_Manager::render_icon( $item['box_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                    </span>
                    <?php elseif($item['tp_box_icon_type'] == 'image') : ?>
                    <span class="tp-el-rep-icon">
                        <img src="<?php echo $item['tp_box_icon_image']['url']; ?>" alt="">
                    </span>
                    <?php else: ?>
                    <span class="tp-el-rep-icon">
                        <?php echo $item['tp_box_icon_svg']; ?>
                    </span>
                    <?php endif; ?>
                </div>
                <?php if(!empty($item['tp_features_title'])) : ?>
                <div class="tp-feature-2-text">
                   <h5 class="tp-feature-2-title tp-el-subtitle"><?php echo tp_kses($item['tp_features_title']); ?></h5>
                </div>
                <?php endif; ?>

                <?php if(!empty($item['tp_features_text'])) : ?>
                <p class="tp-el-content"><?php echo tp_kses($item['tp_features_text']); ?></p>
                <?php endif; ?>
             </div>
          </div>
          <?php endforeach; ?>
       </div>
    </div>
 </div>
</div>


<?php endif; 
	}
}

$widgets_manager->register( new TP_Featres_List() );