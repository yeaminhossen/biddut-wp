<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use TPCore\Elementor\Controls\Group_Control_TPBGGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_CTA extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-cta';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'CTA', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */


	protected function register_controls(){
		$this->register_controls_section();
		$this->style_tab_content();
	}		


	// controls file 
	protected function register_controls_section(){
        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tp-core'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tp-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tp-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // title/content
        $this->tp_section_title_render_controls('cta', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', 'layout-1');


        // Button    
        $this->tp_button_render('cta', 'Button', ['layout-1']); 

        // Button 02
        $this->tp_button_render('cta_2', 'Button 02', ['layout-1']); 


        $this->start_controls_section(
        'tp_cta_video_section',
            [
                'label' => esc_html__( 'Video', 'tpcore' ),
            ]
        );

        $this->add_control(
            'cta_video_url',
            [
                'label' => esc_html__( 'Video URL', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( '#', 'textdomain' ),
                'placeholder' => esc_html__( 'Your youtube or vimeo video url here', 'textdomain' ),
                'label_block' => true,
            ]
        );         

        $this->end_controls_section();
        
        
        // shape
        $this->start_controls_section(
        'tp_shape',
            [
                'label' => esc_html__( 'Shape Section', 'tpcore' ),
            ]
        );

        $this->add_control(
        'tp_shape_switch',
        [
            'label'        => esc_html__( 'Shape On/Off', 'tpcore' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'tpcore' ),
            'label_off'    => esc_html__( 'Hide', 'tpcore' ),
            'return_value' => 'yes',
            'default'      => '0',
        ]
        );

        $this->add_control(
            'tp_shape_image_1',
            [
                'label' => esc_html__( 'Choose Shape Image 1', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_shape_switch' => 'yes',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'shape_image_size', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                'exclude' => ['custom'],
                'condition' => [
                    'tp_shape_switch' => 'yes',
                ]
            ]
        );

        $this->end_controls_section();


	}

	// style_tab_content
	protected function style_tab_content(){
        $this->tp_section_style_controls('cta_section', 'Section Style', '.ele-section'); 
        $this->tp_basic_style_controls('section_subtitle', 'Section - Subtitle', '.tp-el-subtitle', 'layout-1');
        $this->tp_basic_style_controls('section_title', 'Section - Title', '.tp-el-title', 'layout-1');
        $this->tp_basic_style_controls('section_desc', 'Section - Description', '.tp-el-content', 'layout-1');
	}


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>



<?php if ( $settings['tp_design_style']  == 'layout-2' ) : ?>


<?php else:
    // shape image
    if ( !empty($settings['tp_shape_image_1']['url']) ) {
        $tp_shape_image = !empty($settings['tp_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['tp_shape_image_1']['id'], $settings['shape_image_size_size']) : $settings['tp_shape_image_1']['url'];
        $tp_shape_image_alt = get_post_meta($settings["tp_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
    }
    $this->add_render_attribute('title_args', 'class', 'tp-section-title text-white tp-el-title');


    // Link
    if ('2' == $settings['tp_cta_btn_link_type']) {
        $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_cta_btn_page_link']));
        $this->add_render_attribute('tp-button-arg', 'target', '_self');
        $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn hover-2 mr-15 tp-el-btn');
    } else {
        if ( ! empty( $settings['tp_cta_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp-button-arg', $settings['tp_cta_btn_link'] );
            $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn hover-2 mr-15 tp-el-btn');
        }
    }     

    // Link 02
    if ('2' == $settings['tp_cta_2_btn_link_type']) {
        $this->add_render_attribute('tp-button-2-arg', 'href', get_permalink($settings['tp_cta_2_btn_page_link']));
        $this->add_render_attribute('tp-button-2-arg', 'target', '_self');
        $this->add_render_attribute('tp-button-2-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp-button-2-arg', 'class', 'tp-btn-border tp-el-btn');
    } else {
        if ( ! empty( $settings['tp_cta_2_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp-button-2-arg', $settings['tp_cta_2_btn_link'] );
            $this->add_render_attribute('tp-button-2-arg', 'class', 'tp-btn-border tp-el-btn');
        }
    } 

?>

      <div class="tp-video-3-area tp-video-3-bg jarallax p-relative fix pt-140 ele-section">
         <?php if(!empty($settings['cta_video_url'])) : ?>
         <div class="tp-video-3-play-box d-none d-lg-block">
            <a class="popup-video" href="<?php echo esc_url($settings['cta_video_url']); ?>"><i class="fas fa-play"></i></a>
         </div>
         <?php endif; ?>

         <?php if(!empty($settings['tp_shape_switch'])) : ?>
         <div class="tp-video-3-shape-1 d-none d-xxl-block">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/video/text.png" alt="">
         </div>
         <div class="tp-video-3-shape-2 d-none d-xxl-block">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/video/shape-3-1.png" alt="">
         </div>
         <div class="tp-video-3-shape-3 d-none d-xl-block">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/video/shape-3-2.png" alt="">
         </div>
         <?php endif; ?>
         <div class="container">
            <div class="row">
               <div class="col-xl-6 col-lg-6">
                  <div class="tp-video-3-content z-index">
                     <div class="tp-video-3-section-box mb-25">
                        <?php if ( !empty($settings['tp_cta_sub_title']) ) : ?>
                        <span class="tp-section-subtitle text-white"><?php echo tp_kses( $settings['tp_cta_sub_title'] ); ?></span>
                        <?php endif; ?>
                        <?php
                        if ( !empty($settings['tp_cta_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['tp_cta_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            tp_kses( $settings['tp_cta_title' ] )
                            );
                        endif;
                        ?>
                     </div>
                        <?php if ( !empty($settings['tp_cta_description']) ) : ?>
                         <p class="text-white pb-40"><?php echo tp_kses( $settings['tp_cta_description'] ); ?></p>
                        <?php endif; ?>

                     <div class="tp-video-3-btn-box">
                        <?php if ( !empty($settings['tp_cta_btn_text']) ) : ?>
                            <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>><span><?php echo tp_kses($settings['tp_cta_btn_text']); ?></span></a>
                        <?php endif; ?>

                        <?php if ( !empty($settings['tp_cta_2_btn_text']) ) : ?>
                            <a <?php echo $this->get_render_attribute_string( 'tp-button-2-arg' ); ?>><span><?php echo tp_kses($settings['tp_cta_2_btn_text']); ?></span></a>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>


<?php endif; 
	}
}

$widgets_manager->register( new TP_CTA() );