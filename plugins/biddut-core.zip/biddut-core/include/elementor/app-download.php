<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use TPCore\Elementor\Controls\Group_Control_TPBGGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_App_Download extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-app-download';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'App Download', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */


	protected function register_controls(){
		$this->register_controls_section();
		$this->style_tab_content();
	}		


	// controls file 
	protected function register_controls_section(){
        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tp-core'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tp-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tp-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // title/content
        $this->tp_section_title_render_controls('cta', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', 'layout-1');
        
        // shape
        $this->start_controls_section(
        'tp_url_section',
            [
                'label' => esc_html__( 'URL', 'tpcore' ),
            ]
        ); 

        $this->add_control(
        'tp_apple_url',
            [
            'label'   => esc_html__( 'Apple Store URL', 'tpcore' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => esc_html__( '#', 'tpcore' ),
            'label_block' => true,
            ]
        );

        $this->add_control(
        'tp_play_url',
            [
            'label'   => esc_html__( 'Play Store URL', 'tpcore' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => esc_html__( '#', 'tpcore' ),
            'label_block' => true,
            ]
        );

        $this->end_controls_section();

        // shape
        $this->start_controls_section(
        'tp_image_section',
            [
                'label' => esc_html__( 'Image and Shape', 'tpcore' ),
            ]
        );

        $this->add_control(
        'tp_shape_switch',
            [
                'label'        => esc_html__( 'Shape On/Off', 'tpcore' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'tpcore' ),
                'label_off'    => esc_html__( 'Hide', 'tpcore' ),
                'return_value' => 'yes',
                'default'      => '0',
            ]
        );

        $this->add_control(
            'tp_image',
            [
                'label' => esc_html__( 'Choose Image 1', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'tp_image_2',
            [
                'label' => esc_html__( 'Choose Image 2', 'tp-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->end_controls_section();


	}

	// style_tab_content
	protected function style_tab_content(){
        $this->tp_section_style_controls('cta_section', 'Section Style', '.tp-ele-section'); 
        $this->tp_basic_style_controls('section_subtitle', 'Section - Subtitle', '.tp-el-subtitle', 'layout-1');
        $this->tp_basic_style_controls('section_title', 'Section - Title', '.tp-el-title', 'layout-1');
        $this->tp_basic_style_controls('section_desc', 'Section - Description', '.tp-el-content', 'layout-1');
	}


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>



<?php if ( $settings['tp_design_style']  == 'layout-2' ) : ?>


<?php else:
    // shape image
    if ( !empty($settings['tp_shape_image_1']['url']) ) {
        $tp_shape_image = !empty($settings['tp_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['tp_shape_image_1']['id'], $settings['shape_image_size_size']) : $settings['tp_shape_image_1']['url'];
        $tp_shape_image_alt = get_post_meta($settings["tp_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
    }
    $this->add_render_attribute('title_args', 'class', 'tp-section-title pb-30 tp-el-title');


?>

      <div class="tp-app-area p-relative black-bg fix pt-120 pb-120 tp-ele-section">
        <?php if ( !empty($settings['tp_shape_switch']) ) : ?>
         <div class="tp-app-shape-1 d-none d-xl-block">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/app/shape-1-3.png" alt="">
         </div>
         <div class="tp-app-shape-2 d-none d-lg-block">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/app/shape-1-1.png" alt="">
         </div>
         <div class="tp-app-shape-3 d-none d-xl-block">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/app/shape-1-2.png" alt="">
         </div>
         <?php endif; ?>
         <?php if ( !empty($settings['tp_image']['url']) ) : ?>
         <div class="tp-app-shape-4 d-none d-lg-block">
            <img src="<?php echo esc_url( $settings['tp_image']['url'] ); ?>" alt="">
         </div>
         <?php endif; ?>
         <?php if ( !empty($settings['tp_image_2']['url']) ) : ?>
         <div class="tp-app-shape-5 d-none d-xl-block">
            <img src="<?php echo esc_url( $settings['tp_image_2']['url'] ); ?>" alt="">
         </div>
         <?php endif; ?>

         <div class="container">
            <div class="row">
               <div class="col-xl-6 col-lg-6">
                  <div class="tp-app-content">
                     <div class="tp-app-section-box pb-35">
                        <?php if ( !empty($settings['tp_cta_sub_title']) ) : ?>
                        <span class="tp-section-subtitle"><?php echo tp_kses( $settings['tp_cta_sub_title'] ); ?></span>
                        <?php endif; ?>
                        <?php
                        if ( !empty($settings['tp_cta_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['tp_cta_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            tp_kses( $settings['tp_cta_title' ] )
                            );
                        endif;
                        ?>
                        <?php if ( !empty($settings['tp_cta_description']) ) : ?>
                         <p><?php echo tp_kses( $settings['tp_cta_description'] ); ?></p>
                        <?php endif; ?>
                     </div>

                     <div class="tp-app-thumb">
                        <?php if ( !empty($settings['tp_apple_url']) ) : ?>
                        <a class="mr-5" href="<?php echo esc_url( $settings['tp_apple_url'] ); ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/app/app-1-1.jpg" alt=""></a>
                        <?php endif; ?>  

                        <?php if ( !empty($settings['tp_play_url']) ) : ?>
                        <a href="<?php echo esc_url( $settings['tp_play_url'] ); ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/app/app-1-2.jpg" alt=""></a>
                        <?php endif; ?>
                     </div>

                  </div>
               </div>
            </div>
         </div>
      </div>


<?php endif; 
	}
}

$widgets_manager->register( new TP_App_Download() );