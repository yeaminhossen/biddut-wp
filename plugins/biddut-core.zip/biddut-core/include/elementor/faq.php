<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_FAQ extends Widget_Base {

	use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-faq';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'FAQ', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */


	protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tpcore'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tpcore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tpcore'),
                    'layout-2' => esc_html__('Layout 2', 'tpcore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->add_control(
            'tp_black_switch',
            [
                'label'        => esc_html__( 'Black On/Off', 'tpcore' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'tpcore' ),
                'label_off'    => esc_html__( 'Hide', 'tpcore' ),
                'return_value' => 'yes',
                'default'      => '0',
                'condition' => [
                    'tp_design_style' => 'layout-1'
                ]
            ]
        );


        $this->end_controls_section();

        // layout Panel
        $this->start_controls_section(
            'tp_faq_section',
            [
                'label' => esc_html__('Title Label', 'tpcore'),
            ]
        );

        $this->add_control(
            'faq_title',
            [
                'label' => esc_html__( 'Title', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Faq', 'textdomain' ),
                'placeholder' => esc_html__( 'Type your text here', 'textdomain' ),
                'label_block' => true,
            ]
        ); 

        $this->add_control(
            'faq_image',
            [
                'label' => esc_html__( 'Choose Image', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'tp_design_style' => ['layout-1']
                ]
            ]
        );

        $this->end_controls_section();


		$this->start_controls_section(
            '_accordion',
            [
                'label' => esc_html__( 'Accordion', 'tpcore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

		$this->add_control(
            'tp_shape_active_switch',
            [
                'label' => esc_html__( 'Active Shape', 'tp-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tp-core' ),
                'label_off' => esc_html__( 'Hide', 'tp-core' ),
                'return_value' => 'yes',
                'default' => 0,
            ]
        );

        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
            'tp_accordion_active_switch',
            [
                'label' => esc_html__( 'Show', 'tp-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'tp-core' ),
                'label_off' => esc_html__( 'Hide', 'tp-core' ),
                'return_value' => 'yes',
                'default' => '0',
            ]
        );

        $repeater->add_control(
            'accordion_title', [
                'label' => esc_html__( 'Accordion Item', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'This is accordion item title' , 'tpcore' ),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'accordion_description',
            [
                'label' => esc_html__('Description', 'tpcore'),
                'description' => tp_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Facilis fugiat hic ipsam iusto laudantium libero maiores minima molestiae mollitia repellat rerum sunt ullam voluptates? Perferendis, suscipit.',
                'label_block' => true,
            ]
        );
        $this->add_control(
            'accordions',
            [
                'label' => esc_html__( 'Repeater Accordion', 'tpcore' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'accordion_title' => esc_html__( 'This is accordion item title #1', 'tpcore' ),
                    ],
                    [
                        'accordion_title' => esc_html__( 'This is accordion item title #2', 'tpcore' ),
                    ],
                    [
                        'accordion_title' => esc_html__( 'This is accordion item title #3', 'tpcore' ),
                    ],
                    [
                        'accordion_title' => esc_html__( 'This is accordion item title #4', 'tpcore' ),
                    ],
                ],
                'title_field' => '{{{ accordion_title }}}',
            ]
        );

        $this->end_controls_section();

	}

	protected function style_tab_content(){
		$this->tp_section_style_controls('faq_section', 'Section - Style', '.tp-el-section');
        $this->tp_basic_style_controls('section_subtitle', 'Section - Subtitle', '.tp-el-subtitle', 'layout-1');
        $this->tp_basic_style_controls('section_title', 'Section - Title', '.tp-el-title', 'layout-1');
        $this->tp_basic_style_controls('section_desc', 'Section - Description', '.tp-el-content', 'layout-1');

        # repeater 
        $this->tp_basic_style_controls('rep_title_style', 'Faq Title', '.tp-el-rep-title', 'layout-1');
        $this->tp_basic_style_controls('rep_des_style', 'Faq Description', '.tp-el-rep-des', 'layout-1');
    }

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>


<?php if ( $settings['tp_design_style']  == 'layout-2' ): ?>
  <div class="tp-faq-area grey-bg-2 tp-el-section">
     <div class="container">
        <div class="row">
            <?php if ( !empty($settings['faq_title']) ) : ?>
           <div class="col-xl-5 col-lg-5 mb-50 wow tpfadeLeft" data-wow-duration=".9s" data-wow-delay=".5s">
              <div class="tp-faq-left-box">
                 <h4 class="tp-section-title">
                    <?php echo tp_kses($settings['faq_title']); ?>
                 </h4>
              </div>
           </div>
           <?php endif; ?>
           <div class="col-xl-7 col-lg-7 mb-50 wow tpfadeRight" data-wow-duration=".9s" data-wow-delay=".7s">
              <div class="tp-custom-accordion-2">
                 <div class="accordion" id="accordionExample">
                    <?php foreach ( $settings['accordions'] as $key => $item) : 
                        $collapsed = $key == 0 ? '' : 'collapsed';
                        $show = $key == 0 ? 'show' : '';
                    ?>
                    <div class="accordion-items tp-faq-active">
                       <h2 class="accordion-header" id="headingOne">
                          <button class="accordion-buttons <?php echo esc_attr($collapsed); ?>" type="button" data-bs-toggle="collapse"
                             data-bs-target="#collapseOne-<?php echo esc_attr($key); ?>" aria-expanded="true" aria-controls="collapseOne-<?php echo esc_attr($key); ?>">
                             <?php echo esc_html($item['accordion_title']); ?>
                          </button>
                       </h2>
                       <div id="collapseOne-<?php echo esc_attr($key); ?>" class="accordion-collapse collapse <?php echo esc_attr($show); ?>"
                          aria-labelledby="headingOne-<?php echo esc_attr($key); ?>" data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                             <?php echo tp_kses($item['accordion_description']); ?>
                          </div>
                       </div>
                    </div>
                    <?php endforeach; ?>
                 </div>
              </div>
           </div>
        </div>
     </div>
  </div>



<?php else : 

    // thumbnail
    if ( !empty($settings['faq_image']['url']) ) {
        $faq_image = !empty($settings['faq_image']['id']) ? wp_get_attachment_image_url( $settings['faq_image']['id'], 'full') : $settings['faq_image']['url'];
        $faq_image_alt = get_post_meta($settings["faq_image"]["id"], "_wp_attachment_image_alt", true);
    }  
    $black = $settings['tp_black_switch'] ? 'tp-black-mode black-bg' : ''; 
?>

<div class="tp-faq-area p-relative pt-120 pb-120 tp-el-section <?php echo esc_attr($black); ?>">
 <?php if ( !empty($faq_image) ) : ?>   
 <div class="tp-faq-thumb" style="background-image:url(<?php echo esc_url($faq_image); ?>)"></div>
 <?php endif; ?>
 <?php if ( !empty($settings['faq_title']) ) : ?>
 <div class="tp-faq-text d-none d-xxl-block">
    <h5><?php echo tp_kses($settings['faq_title']); ?></h5>
 </div>
<?php endif; ?>
 <div class="container">
    <div class="row">
       <div class="col-xxl-7 col-xl-6 col-lg-6 wow tpfadeLeft" data-wow-duration=".9s" data-wow-delay=".s">
          <div class="tp-custom-accordion">
             <div class="accordion" id="accordionExample">
                <?php foreach ( $settings['accordions'] as $key => $item) : 
                    $collapsed = $key == 0 ? '' : 'collapsed';
                    $show = $key == 0 ? 'show' : '';
                ?>
                <div class="accordion-items tp-faq-active">
                   <h2 class="accordion-header" id="headingOne">
                      <button class="accordion-buttons <?php echo esc_attr($collapsed); ?>" type="button" data-bs-toggle="collapse"
                         data-bs-target="#collapseOne-<?php echo esc_attr($key); ?>" aria-expanded="true" aria-controls="collapseOne-<?php echo esc_attr($key); ?>">
                        <?php echo esc_html($item['accordion_title']); ?>
                      </button>
                   </h2>
                   <div id="collapseOne-<?php echo esc_attr($key); ?>" class="accordion-collapse collapse <?php echo esc_attr($show); ?>"
                      aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                      <div class="accordion-body">
                         <?php echo tp_kses($item['accordion_description']); ?>
                      </div>
                   </div>
                </div>
                <?php endforeach; ?>
             </div>
          </div>
       </div>
    </div>
 </div>
</div>

<?php endif;
	}

}

$widgets_manager->register( new TP_FAQ() );