<?php
namespace TPCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use TPCore\Elementor\Controls\Group_Control_TPBGGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tp Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TP_CTA_2 extends Widget_Base {

    use \TPCore\Widgets\TPCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tp-cta-2';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'CTA 02', 'tpcore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'tp-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'tpcore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'tpcore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */


	protected function register_controls(){
		$this->register_controls_section();
		$this->style_tab_content();
	}		


	// controls file 
	protected function register_controls_section(){
        // layout Panel
        $this->start_controls_section(
            'tp_layout',
            [
                'label' => esc_html__('Design Layout', 'tp-core'),
            ]
        );
        $this->add_control(
            'tp_design_style',
            [
                'label' => esc_html__('Select Layout', 'tp-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'tp-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // layout Panel
        $this->start_controls_section(
            'tp_cta2_section',
            [
                'label' => esc_html__('Left Content', 'tp-core'),
            ]
        );

        $this->add_control(
            'cta_left_title',
            [
                'label' => esc_html__( 'Title', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'This is title', 'textdomain' ),
                'placeholder' => esc_html__( 'Type your text here', 'textdomain' ),
                'label_block' => true,
            ]
        ); 

        $this->add_control(
            'left_image',
            [
                'label' => esc_html__( 'Choose Image', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->end_controls_section();

        // layout Panel
        $this->start_controls_section(
            'tp_cta2_right_section',
            [
                'label' => esc_html__('Right Content', 'tp-core'),
            ]
        );

        $this->add_control(
            'cta_right_title',
            [
                'label' => esc_html__( 'Title', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'This is title', 'textdomain' ),
                'placeholder' => esc_html__( 'Type your text here', 'textdomain' ),
                'label_block' => true,
            ]
        ); 

        $this->add_control(
            'right_image',
            [
                'label' => esc_html__( 'Choose Image', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->end_controls_section();

        // Button    
        $this->tp_button_render('cta', 'Button', ['layout-1']); 



	}

	// style_tab_content
	protected function style_tab_content(){
        $this->tp_section_style_controls('cta_section', 'Section Style', '.ele-section'); 
        $this->tp_basic_style_controls('section_subtitle', 'Section - Subtitle', '.tp-el-subtitle', 'layout-1');
        $this->tp_basic_style_controls('section_title', 'Section - Title', '.tp-el-title', 'layout-1');
        $this->tp_basic_style_controls('section_desc', 'Section - Description', '.tp-el-content', 'layout-1');
	}


	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>



<?php if ( $settings['tp_design_style']  == 'layout-2' ) : ?>


<?php else:
    // left image
    if ( !empty($settings['left_image']['url']) ) {
        $left_image = !empty($settings['left_image']['id']) ? wp_get_attachment_image_url( $settings['left_image']['id'], 'full') : $settings['left_image']['url'];
        $left_image_alt = get_post_meta($settings["left_image"]["id"], "_wp_attachment_image_alt", true);
    }    

    // right image
    if ( !empty($settings['right_image']['url']) ) {
        $right_image = !empty($settings['right_image']['id']) ? wp_get_attachment_image_url( $settings['right_image']['id'], 'full') : $settings['right_image']['url'];
        $right_image_alt = get_post_meta($settings["right_image"]["id"], "_wp_attachment_image_alt", true);
    }

    $this->add_render_attribute('title_args', 'class', 'tp-section-title text-white tp-el-title');


    // Link
    if ('2' == $settings['tp_cta_btn_link_type']) {
        $this->add_render_attribute('tp-button-arg', 'href', get_permalink($settings['tp_cta_btn_page_link']));
        $this->add_render_attribute('tp-button-arg', 'target', '_self');
        $this->add_render_attribute('tp-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn-black hover-2 tp-el-btn');
    } else {
        if ( ! empty( $settings['tp_cta_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'tp-button-arg', $settings['tp_cta_btn_link'] );
            $this->add_render_attribute('tp-button-arg', 'class', 'tp-btn-black hover-2 tp-el-btn');
        }
    }     

?>

      <div class="tp-cta-3-area fix">
         <div class="container-fluid p-0">
            <div class="row g-0">
               <div class="col-xl-6 col-lg-6">
                  <div class="tp-cta-3-left-wrap theme-bg z-index-3 p-relative">
                     <div class="tp-cta-3-left-shape d-none d-xl-block">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/cta/shape-3-1.png" alt="">
                     </div>
                     <div class="tp-cta-3-left-box">
                        <div class="row align-items-center">
                            <?php if ( !empty($left_image) ) : ?>
                           <div class="col-xl-6 col-lg-6 col-md-5 d-none d-md-block">
                              <div class="tp-cta-3-left-thumb">
                                 <img src="<?php echo esc_url($left_image); ?>" alt="">
                              </div>
                           </div>
                            <?php endif; ?>
                           <div class="col-xl-6 col-lg-6 col-md-7">
                              <div class="tp-cta-3-left-text text-center text-md-start">
                                <?php if ( !empty($settings['cta_left_title']) ) : ?>
                                 <h5 class="tp-cta-3-left-title"><?php echo tp_kses($settings['cta_left_title']); ?></h5>
                                 <?php endif; ?>
                                <?php if ( !empty($settings['tp_cta_btn_text']) ) : ?>
                                    <a <?php echo $this->get_render_attribute_string( 'tp-button-arg' ); ?>><span><?php echo tp_kses($settings['tp_cta_btn_text']); ?></span></a>
                                <?php endif; ?>
                              </div>
                           </div>
                        </div>  
                     </div>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6">
                  <div class="tp-cta-3-right-wrap black-bg">                     
                     <div class="tp-cta-3-right-box jarallax z-index" style="background-image:url(<?php echo esc_url($right_image); ?>);">
                        <?php if ( !empty($settings['cta_left_title']) ) : ?>
                        <h4 class="tp-section-title text-white text-center z-index-3"><?php echo tp_kses($settings['cta_right_title']); ?></h4>
                        <?php endif; ?>
                        <div class="tp-cta-3-right-shape">
                           <img src="<?php echo get_template_directory_uri(); ?>/assets/img/cta/shape-3-2.png" alt="">
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>


<?php endif; 
	}
}

$widgets_manager->register( new TP_CTA_2() );